package model.library;

public class FictionBook extends Book {
    private String genre;
    public FictionBook(String title, String author, String ISBN, boolean isAvailable, String genre) {
        super(title, author, ISBN, isAvailable);
        this.genre = genre;
    }

    public void displayDetails() {
        super.displayDetails();
        System.out.println("Genre: " + genre);
    }
}
