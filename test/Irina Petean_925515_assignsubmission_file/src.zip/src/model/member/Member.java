package model.member;

import java.util.ArrayList;
import java.util.List;

public class Member {
    private String name;
    private String memberID;
    private List<String> loanHistory;

    public Member(String name, String memberID) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>();
    }
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Member ID: " + memberID);
        System.out.println("Loan History: " + loanHistory);
    }

    public List<String> getLoanHistory() {
        return loanHistory;
    }

    public void setLoanHistory(List<String> loanHistory) {
        this.loanHistory = loanHistory;
    }
    public void addLoanToHistory(String bookTitle) {
        loanHistory.add(bookTitle);
    }
}
