package test;

import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;

import java.util.Arrays;

public class LibraryTest {
    public static void main(String[] args) {
        FictionBook book1 = new FictionBook("Dune", "Frank Herbert","1a2b3", true, "Science Fiction");
        NonFictionBook book2 = new NonFictionBook("A Brief History of Time", "Stephen Hawking", "67890", true, "Science");

        Member member1 = new Member("Iulia", "M001");
        Member member2 = new Member("Irina", "M002");

        LoanService loanService = new LoanService();
        loanService.addBooks(book1);
        loanService.addBooks(book2);

        System.out.println(loanService.returnBook(book1));
        System.out.println(loanService.loanBook(book1, member2));

        System.out.println("Fine: " + loanService.calculateFine(5));
        System.out.println("VIP Fine: "  + loanService.calculateFine(5, true));

        book1.displayDetails();
        book2.displayDetails();
        member1.displayInfo();
        member2.displayInfo();

        Book[] searchResults = loanService.search("Time");
        System.out.println("Search results: ");
        Arrays.stream(searchResults).forEach(System.out::println);

    }
}