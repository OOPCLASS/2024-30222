package service;

import model.library.Book;
import model.member.Member;

import java.util.ArrayList;
import java.util.List;

public class LoanService {
    private List<Book> books;
    public LoanService() {
        books = new ArrayList<>();
    }
    public void addBooks(Book book) {
        books.add(book);
    }
    public String loanBook(Book book, Member member) {
        if(book.checkAvailable()){
            book.setAvailable(false);
            member.addLoanToHistory(book.getTitle());
            return "Loaning successful! ";
        }else{
            return "Book not available for loaning. ";
        }
    }
    public boolean returnBook(Book book){
        if(!book.checkAvailable()){
            book.setAvailable(true);
            return true;
        }
        return false;
    }
    public static int calculateFine(int daysOverdue){
        return daysOverdue * 2;
    }
    public static int calculateFine(int daysOverdue, boolean isMemberVIP) {
        int fine = calculateFine(daysOverdue);
        return isMemberVIP ? fine / 2 : fine;
    }
    public Book[] search(String value){
        List<Book> results = new ArrayList<>();
        for(Book book : books){
            if(book.getTitle().toLowerCase().contains(value.toLowerCase()) || book.getAuthor().toLowerCase().contains(value.toLowerCase())){
                results.add(book);
            }
        }
        return results.toArray(new Book[0]);
    }
}
