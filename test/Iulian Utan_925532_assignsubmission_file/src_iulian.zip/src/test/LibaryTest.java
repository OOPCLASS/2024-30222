package test;

import model.library.*;
import model.member.Member;
import service.LoanService;

import java.util.Arrays;
import java.util.List;

public class LibaryTest {
    public static void main(String[] args) {
        //cream cartile

        FictionBook book1 = new FictionBook("Jurnalele unui Vampir", "Marian Preda", "2222", true, "Fiction");
        NonFictionBook book2 = new NonFictionBook("Plumb", "George Bacovia", "23232",true, "Realism");

        //cream membri

        Member member1 = new Member("Erdic P.", "100");
        Member member2 = new Member("Iulian", "101",List.of("O carte random inchiriata candva"));

        //testing

        LoanService loanService = new LoanService();
        System.out.println(loanService.loanBook(book1, member1));
        System.out.println(loanService.loanBook(book2, member2));
        System.out.println(loanService.returnBook(book1));

        //vedem intarzierile

        System.out.println("2 days overdue = $" + LoanService.calculateFine(2));
        //sugerat de copilot
        System.out.println("2 days overdue = $" + LoanService.calculateFine(2, true) + " (VIP discount)");

        //cautam cartile

        Book[] books = {book1, book2};
        Book[] searchResults = loanService.search(books, "Plumb");
        System.out.println(Arrays.toString(searchResults));
        for (Book book : searchResults) {
            book.displayDetails();
        }

        //afisam info membri

        member1.displayInfo();
        member2.displayInfo();

    }
}