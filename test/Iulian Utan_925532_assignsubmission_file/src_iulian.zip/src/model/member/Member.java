package model.member;

import java.util.ArrayList;
import java.util.List;

public class Member {
    private String name;
    private String memberID;
    private List<String> loanHistory;

    // Constructor
    public Member(String name, String memberID) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>(); // Initialize as modifiable list
    }

    // Overloaded Constructor
    public Member(String name, String memberID, List<String> loanHistory) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>(loanHistory); // Copy into modifiable list
    }

    // Add to loan history
    public void addToLoanHistory(String bookDetails) {
        loanHistory.add(bookDetails); // No more UnsupportedOperationException
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Member ID: " + memberID);
        System.out.println("Loan History: " + loanHistory);
    }
}
