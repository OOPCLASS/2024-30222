package model.library;

public class Book {
    private String title;
    private String author;
    private String ISBN;
    private boolean isAvailable;

    //facem constructorul
    public Book(String title, String author, String ISBN, boolean isAvailable) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }
    public String getISBN() {
        return ISBN;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        this.isAvailable = available;
    }

    public void displayDetails() {
        System.out.println("Title : " + title + " ");
        System.out.println("Author : " + author + " ");
        System.out.println("ISBN : " + ISBN + " ");
        System.out.println("Available : " + isAvailable + " ");
    }

    public boolean checkAvailability() {
        return isAvailable;
    }

}
