package service;

import model.library.Book;
import model.member.Member;

import java.util.Arrays;

public class LoanService {

    public String loanBook(Book book, Member member) {
        if (book == null || member == null) {
            return "Error! Book or Membr is null.";
        }
        if (!book.isAvailable()) {
            return "Book not available for loaning.";
        }
        book.setAvailable(false);
        member.addToLoanHistory(book.getTitle() + " by " + book.getAuthor());
        return "Loaning successful.";
    }


    public boolean returnBook(Book book) {
        if (!book.isAvailable()) {
            book.setAvailable(true);
            return true;
        }
        return false;
    }

    public static int calculateFine(int daysOverdue) {
        return daysOverdue * 2;
    }

    public static int calculateFine(int daysOverdue, boolean isMemberVIP) {
        int fine = calculateFine(daysOverdue);
        return isMemberVIP ? fine / 2 : fine;
    }
    //search sugerat de COPILOT
    // Oh, and the search method? Your first reaction was, “Nah, too complicated, let’s dumb it down!”
    // Look, Java’s stream API isn’t a riddle—it’s literally designed to save you from writing loops like it’s 1999.
    // But nah, you wanted to give your examiner some nostalgic 20th-century vibes.

    //i-am zis sa mi dea roast si mi o dat asta xD

    public Book[] search(Book[] books, String value) {
        return Arrays.stream(books)
                .filter(book -> book.getTitle().toLowerCase().contains(value.toLowerCase()) ||
                        book.getAuthor().toLowerCase().contains(value.toLowerCase()))
                .toArray(Book[]::new);
    }

    //
}
