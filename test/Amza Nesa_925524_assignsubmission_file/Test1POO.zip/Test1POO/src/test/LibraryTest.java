package test;

import model.library.*;
import model.member.Member;
import service.LoanService;

import java.util.ArrayList;
import java.util.List;

public class LibraryTest {
    public static void main(String[] args) {

        FictionBook fictionBook1 = new FictionBook("The Great Gatsby", "F. Scott Fitzgerald", "123456", true, 2, "Classic");
        FictionBook fictionBook2 = new FictionBook("1984", "George Orwell", "234567", true, 1, "Dystopian");
        FictionBook fictionBook3 = new FictionBook("Harry Potter and the Sorcerer's Stone", "J.K. Rowling", "345678", true, 3, "Fantasy");
        FictionBook fictionBook4 = new FictionBook("Pride and Prejudice", "Jane Austen", "456789", true, 1, "Romance");


        NonFictionBook nonFictionBook1 = new NonFictionBook("Sapiens", "Yuval Noah Harari", "789101", true, 2, "History");
        NonFictionBook nonFictionBook2 = new NonFictionBook("Educated", "Tara Westover", "890123", true, 1, "Memoir");
        NonFictionBook nonFictionBook3 = new NonFictionBook("The Immortal Life of Henrietta Lacks", "Rebecca Skloot", "901234", true, 1, "Biography");
        NonFictionBook nonFictionBook4 = new NonFictionBook("Brief Answers to the Big Questions", "Stephen Hawking", "012345", true, 1, "Science");


        List<Book> books = new ArrayList<>();
        books.add(fictionBook1);
        books.add(fictionBook2);
        books.add(fictionBook3);
        books.add(fictionBook4);
        books.add(nonFictionBook1);
        books.add(nonFictionBook2);
        books.add(nonFictionBook3);
        books.add(nonFictionBook4);


        Member member1 = new Member("Alice", "M001", "Regular");
        Member member2 = new Member("Bob", "M002", "VIP");
        Member member3 = new Member("Jake", "M003", "Regular");
        Member member4 = new Member("Mike", "M004", "VIP");
        Member member5 = new Member("Gabriel", "M005", "Regular");


        LoanService loanService = new LoanService(books);

 
        System.out.println(member1.getName() + ": " + loanService.loanBook(fictionBook1, member1));
        System.out.println(member2.getName() + ": " + loanService.loanBook(fictionBook2, member2));
        System.out.println(member3.getName() + ": " + loanService.loanBook(nonFictionBook1, member3));
        System.out.println(member4.getName() + ": " + loanService.loanBook(nonFictionBook4, member4));
        System.out.println(member5.getName() + ": " + loanService.loanBook(fictionBook1, member5));
        System.out.println(member5.getName() + ": " + loanService.loanBook(nonFictionBook4, member5));

        System.out.println();


        System.out.println("Return Status for The Great Gatsby: " + loanService.returnBook(fictionBook1));
        System.out.println("Return Status for 1984: " + loanService.returnBook(fictionBook2));
        System.out.println("Return Status for Brief Answers to the Big Questions: " + loanService.returnBook(nonFictionBook4));
        System.out.println();


        System.out.println("Fine (8 days overdue): $" + LoanService.calculateFine(8));
        System.out.println("Fine (8 days overdue, VIP): $" + LoanService.calculateFine(8, true));
        System.out.println();


        System.out.println("'great'");
        Book[] searchResults1 = loanService.search("great");
        for (Book book : searchResults1) {
            book.displayDetails();
            System.out.println();
        }

        System.out.println("'we'");
        Book[] searchResults2 = loanService.search("we");
        for (Book book : searchResults2) {
            book.displayDetails();
            System.out.println();
        }


        System.out.println("Member Information:");
        System.out.println();
        
        member1.displayInfo();
        System.out.println();
        member2.displayInfo();
        System.out.println();
        member3.displayInfo();
        System.out.println();
        member4.displayInfo();
        System.out.println();
        member5.displayInfo();
        System.out.println();
        
    }
}
