package model.member;

import java.util.ArrayList;
import java.util.List;

public class Member {
    private String name;
    private String memberID;
    private List<String> loanHistory;
    private String memberType = "Regular";
    private int maxLoanLimit = 5;

    public Member(String name, String memberID, String memberType) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>();
        this.memberType = memberType;
        this.maxLoanLimit = memberType.equals("VIP") ? 15 : 5;
    }

    public Member(String name, String memberID, List<String> loanHistory) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>(loanHistory);
    }

    public boolean canBorrowMoreBooks() {
        return loanHistory.size() < maxLoanLimit;
    }
    
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Member ID: " + memberID);
        System.out.println("Type: " + memberType);
        System.out.println("Loan History: " + loanHistory);
        System.out.println("Books Allowed to Borrow: " + (maxLoanLimit - loanHistory.size()));
    }

    public void addLoanHistory(String bookDetails) {
        loanHistory.add(bookDetails);
    }
    
    public String getName() {
        return name;
    }
}
