package model.library;

public class NonFictionBook extends Book {
    private String fieldOfStudy;

    public NonFictionBook(String title, String author, String ISBN, boolean isAvailable, int copiesAvailable, String fieldOfStudy) {
        super(title, author, ISBN, isAvailable, copiesAvailable);
        this.fieldOfStudy = fieldOfStudy;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Field of Study: " + fieldOfStudy);
        System.out.println();
    }
}
