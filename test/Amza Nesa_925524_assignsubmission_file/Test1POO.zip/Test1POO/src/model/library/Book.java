package model.library;

public class Book {
    private String title;
    private String author;
    private String ISBN;
    private boolean isAvailable;
    private int copiesAvailable;

    public Book(String title, String author, String ISBN, boolean isAvailable, int copiesAvailable) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
        this.copiesAvailable = copiesAvailable;
    }

    public void displayDetails() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("ISBN: " + ISBN);
        System.out.println("Available: " + (isAvailable ? "Yes" : "No"));
        System.out.println("Copies available: " + copiesAvailable);
    }

    public boolean checkAvailability() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }
    
    public void updateAvailability(boolean isLoan) {
        if (isLoan && copiesAvailable > 0) {
            copiesAvailable--;
        } else if (!isLoan) {
            copiesAvailable++;
        }
        isAvailable = copiesAvailable > 0;
    }
}

