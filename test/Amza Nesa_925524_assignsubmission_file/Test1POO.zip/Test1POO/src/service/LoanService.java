package service;

import model.library.Book;
import model.member.Member;

import java.util.ArrayList;
import java.util.List;

public class LoanService {
    private List<Book> books;

    public LoanService(List<Book> books) {
        this.books = books;
    }

    public String loanBook(Book book, Member member) {
        if (!book.checkAvailability()) {
            return "Book not available for loaning.";
        }
        book.setAvailable(false);
        member.addLoanHistory(book.getTitle());
        return "Loaning successful.";
    }

    public boolean returnBook(Book book) {
        if (!book.checkAvailability()) {
            book.setAvailable(true);
            return true;
        }
        return false;
    }

    public static int calculateFine(int daysOverdue) {
        return daysOverdue * 2;
    }

    public static int calculateFine(int daysOverdue, boolean isMemberVIP) {
        int fine = calculateFine(daysOverdue);
        return isMemberVIP ? fine / 2 : fine;
    }

    public Book[] search(String value) {
        List<Book> result = new ArrayList<>();
        for (Book book : books) {
            if (book.getTitle().toLowerCase().contains(value.toLowerCase()) ||
                book.getAuthor().toLowerCase().contains(value.toLowerCase())) {
                result.add(book);
            }
        }
        return result.toArray(new Book[0]);
    }
}
