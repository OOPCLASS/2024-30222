package service;

import library.Book;
import member.Member;

public class LoanService {

    static public String loanBook(Book book, Member member) {
        if(book.checkAvailability()) {
            book.setAvailable(false);
            for(int i = 0; i < member.loans.length; i++) {
                if(member.loans[i] == null) {
                    member.loans[i] = book;
                    break;
                }

            }
            return "Loaning Successful";
        }
        else return "Book is not Available for loaning! Please come back LATER!";
    }

    public static boolean returnBook(Book book) {
        if(book.checkAvailability()) {
            System.out.println("Error! Book was already in the library!");
            return false;
        }

        book.setAvailable(true);
        return true;
    }

    public static int calculateFine(Member member, int daysOverdue) {
        return 0;
    }

    static public Book[] search(Book[] allBooks, String name) {
        Book[] foundBooks = new Book[allBooks.length];

        int j = 0;
        for(int i = 0; i < allBooks.length; i++) {
            if(allBooks[i].getTitle().contains(name)) {
                foundBooks[j] = allBooks[i];
                j++;
            }
            else foundBooks[i] = null;
        }
        return foundBooks;
    }
}
