package test;

import library.Book;
import library.FictionBook;
import library.NonFictionBook;
import member.Member;
import service.LoanService;

public class LibraryTest {
    public LibraryTest() {

        //test book class
        System.out.println("Library Test: Book Class");
        Book book1 = new Book("IT", "Stefan", 34, true);
        Book book2 = new Book("IT (1983)", "Alex", 35, false);
        Book book3 = new NonFictionBook("Matematici Speciale", "Dorian Pop", 32, true, "Math");
        Book book4 = new FictionBook("Cum a fost scrisa cartea IT", "Antonio", 30, false, "Horror");
        book1.displayDetails();
        book2.displayDetails();
        book3.displayDetails();
        book4.displayDetails();
        System.out.print("\n");

        //test member class
        System.out.println("Library Test: Member Class");
        Member member1 = new Member("Antonio Reti", 13);
        member1.displayInfo();

        Book[] books = {book1, book2, book3, book4};
        Member member2 = new Member("Alexandru Cristian", 14, books);
        member2.displayInfo();
        System.out.print("\n");

        //test loanService class
        System.out.println("Library Test: Loan Service Class");

            //test return book
        System.out.println("Library Test: Return Book Method");
        boolean testReturn = new LoanService().returnBook(book2);
        book2.displayDetails();
        System.out.print("\n");

            //test search
        System.out.println("Library Test: Search Books Method");
        Book[] searchTest = new LoanService().search(books,"IT");
        for(int i = 0; i < searchTest.length; i++)
            if(searchTest[i] != null)
                searchTest[i].displayDetails();
        System.out.print("\n");

            //test loan
        System.out.println("Library Test: Loan Books Method");
        System.out.println(new LoanService().loanBook(book1, member1));
        book1.displayDetails();
        member1.displayInfo();
        System.out.print("\n");
    }
}
