package member;

import library.Book;

public class Member {
    protected String name;
    protected int memberID;
    public Book[] loans = new Book[100];
    private static final boolean vipStatus = false;

    public Member() {}

    public Member(String name, int memberID) {
        this.name = name;
        this.memberID = memberID;
    }

    public Member(String name, int memberID, Book[] loans) {
        this.name = name;
        this.memberID = memberID;
        this.loans = loans;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Member ID: " + memberID);
        if (loans[1] != null) {
            System.out.println("Previous or ongoing loans: ");

            for(int i = 0; i < loans.length; i++) {
                    System.out.print(i+1 + ". ");
                    loans[i].displayDetailsForMembers();
            }
        }
        else System.out.println("No Previous Loans");
    }
}
