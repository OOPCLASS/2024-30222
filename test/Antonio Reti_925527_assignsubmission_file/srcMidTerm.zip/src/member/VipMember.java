package member;

import library.Book;

public class VipMember extends Member {
     private static final boolean vipStatus = true;

    public VipMember(String name, int memberID) {
        this.name = name;
        this.memberID = memberID;
    }

    public VipMember(String name, int memberID, Book[] loans) {
        this.name = name;
        this.memberID = memberID;
        this.loans = loans;
    }
}
