package library;

public class Book {

    protected String title;
    protected String author;
    protected int ISBN;
    protected boolean isAvailable;

    public Book() {

    }

    public Book(String title, String author, int ISBN, boolean isAvailable) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
    }

    public void displayDetails() {
        System.out.println("Title: " + title + " | Author: " + author + " | ISBN: " + ISBN + " | Available: " + availableStringConvertor());
    }

    public boolean checkAvailability() {
        if(isAvailable) return true;
        else return false;
    }

    public void displayDetailsForMembers() {
        System.out.println("Title: " + title + " | Author: " + author);
    }

    public String availableStringConvertor() {
        if (isAvailable) {
            return "Available to Loan in the Library";
        }
        else return "Not Available to loan in the Library";
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public String getTitle() {
        return title;
    }
}
