package library;

public class NonFictionBook extends Book {
    private String fieldOfStudy;

    public NonFictionBook(String title, String author, int ISBN, boolean isAvailable, String fieldOfStudy) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
        this.fieldOfStudy = fieldOfStudy;
    }
    public void displayDetails() {
        System.out.println("Title: " + title + " | Author: " + author + " | ISBN: " + ISBN + " | Field of Study: " + fieldOfStudy + " | Available: " + availableStringConvertor());
    }
}
