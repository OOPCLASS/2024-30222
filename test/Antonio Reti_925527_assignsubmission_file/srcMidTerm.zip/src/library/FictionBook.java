package library;

public class FictionBook extends Book {

    private String genre;

    public FictionBook(String title, String author, int ISBN, boolean isAvailable, String genre) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
        this.genre = genre;
    }
    public void displayDetails() {
        System.out.println("Title: " + title + " | Author: " + author + " | ISBN: " + ISBN + " | Genre: " + genre + " | Available: " + availableStringConvertor());
    }

}
