package service;

import model.library.Book;
import model.member.Member;

import java.util.ArrayList;
import java.util.List;

public class LoanService {
    private List<Book> books;

    public LoanService() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public String loanBook(Book book, Member member) {
        if (book.checkAvailability()) {
            book.setAvailable(false);
            member.addLoan(book.getTitle());
            return "Loaning successful";
        } else {
            return "Book not available for loaning";
        }
    }

    public boolean returnBook(Book book) {
        if (!book.checkAvailability()) {
            book.setAvailable(true);
            return true;
        }
        return false;
    }

    public static int calculateFine(int daysOverdue) {
        return daysOverdue * 2;
    }

    public static int calculateFine(int daysOverdue, boolean isMemberVIP) {
        int fine = calculateFine(daysOverdue);
        return isMemberVIP ? fine / 2 : fine;
    }

    public Book[] search(String value) {
        List<Book> result = new ArrayList<>();
        String lowerCaseValue = value.toLowerCase();
        for (Book book : books) {
            if (book.getTitle().toLowerCase().contains(lowerCaseValue) || book.getAuthor().toLowerCase().contains(lowerCaseValue)) {
                result.add(book);
            }
        }
        return result.toArray(new Book[0]);
    }
}