package model.member;

import java.util.ArrayList;
import java.util.List;

public class Member {
    private String name;
    private String memberID;
    private List<String> loanHistory;

    public Member(String name, String memberID) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>();
    }

    public Member(String name, String memberID, List<String> loanHistory) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>(loanHistory);
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("ID: " + memberID);
        System.out.println("Loan History: " + loanHistory);
    }

    public void addLoan(String loan) {
        loanHistory.add(loan);
    }

    // Getter
    public String getName() {
        return name;
    }
}
