package test;

import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;

import java.util.Arrays;

public class LibraryTest {
    public static void main(String[] args) {
        Book book1 = new NonFictionBook("A Brief History of Time", "Stephen Hawking", "9780553380163", "Physics");
        Book book2 = new FictionBook("The Little Prince", "Antoine de Saint-Exupery", "9780156012195", "Children's Literature");
        Book book3 = new FictionBook("IT", "Stephen King", "9781501142970", "Horror");
        Book book4 = new FictionBook("Murder on the Orient Express", "Agatha Christie", "9780062693662", "Mystery");

        Member member1 = new Member("Ban Ana", "1234");
        Member member2 = new Member("dr. Lena Elena", "5678", Arrays.asList("Previous Book"));

        LoanService loanService = new LoanService();
        loanService.addBook(book1);
        loanService.addBook(book2);
        loanService.addBook(book3);
        loanService.addBook(book4);

        System.out.println(loanService.loanBook(book1, member1));
        System.out.println(loanService.loanBook(book2, member2));
        System.out.println(loanService.loanBook(book1, member2));
        System.out.println(loanService.loanBook(book3, member2));

        System.out.println("\nBook Information:");
        book1.displayDetails();
        book2.displayDetails();
        book3.displayDetails();
        book4.displayDetails();

        System.out.println("\nMember Information:");
        member1.displayInfo();
        member2.displayInfo();

        System.out.println("\nReturning book:");
        System.out.println(loanService.returnBook(book1));

        System.out.println("\nFine Calculation:");
        System.out.println("Regular fine for 5 days: $" + LoanService.calculateFine(5, false));
        System.out.println("VIP fine for 5 days: $" + LoanService.calculateFine(5, true));

        System.out.println("\nSearch Results for 'the':");
        Book[] searchResults1 = loanService.search("the");
        for (Book book : searchResults1) {
            book.displayDetails();
            System.out.println();
        }

        System.out.println("\nSearch Results for 'i':");
        Book[] searchResults2 = loanService.search("i");
        for (Book book : searchResults2) {
            book.displayDetails();
            System.out.println();
        }
    }
}
