package test;

import ro.model.library.Book;
import ro.model.library.FictionBook;
import ro.model.library.NonFictionBook;
import ro.model.member.Member;
import service.LoanService;

import java.text.Format;

public class LibraryTest {
    public static void main(String[] args) {
        Book b1=new Book("normala1","dsad123",true);
        Book b2=new Book("normala2","sdaf12edas",true);
        Book b3=new FictionBook("fictione1","sad12dgfsf",false,"g1");
        Book b4=new NonFictionBook("non1","dsbbfdcas2",true,"math");
        Book b5=new NonFictionBook("non2","fdhscwdad1",false,"cs");

        System.out.println("Print library:");
        Book.displayLibrary();

        Member m1=new Member(1,"radu");
        Member m2=new Member(2,"marian",b1);

        LoanService l1=new LoanService();
        System.out.println("\nImprumut unei carti care exista in librarie");
        l1.loanBook(b4,m1);

        System.out.println("\nDupa ce Radu a imprumutat o carte:");
        m1.displayInfo();

        System.out.println("\nDupa ce Marian a imprumutat o carte care nu este valabila ,dar are b1 de la constructor:");
        System.out.println(l1.loanBook(b3,m2));
        m2.displayInfo();

        System.out.println("\nReturnarea cartii 3:");
        l1.returnBook(b3);

        System.out.println("\nVerificare daca se modifica valabilitate:");
        System.out.println(b3.isAvailable());

        System.out.println("\nTest fines:");
        LoanService.calculateFine(10);
        LoanService.calculateFine(10,true);

        System.out.println("\nToti membrii:");
        Member.displayMembers();


        System.out.println("\nToate cartile care contin no");
        Book[] books=l1.search("no");
        for(Book b: books){
            if(b!=null) {
                b.displayDetails();
            }
        }
    }

}
