package service;

import ro.model.library.Book;
import ro.model.member.Member;

public class LoanService {

    public String loanBook(Book book, Member member){
            if(book.checkAvailability()){
                System.out.println("this book is available");
                member.addLoan(book);
                book.setAvailable(false);
                return "’loaning successful";
            }
            else {
                return "book not available for loaning";
            }
    }

    public boolean returnBook(Book book){
        if(book !=null)
        {
            book.setAvailable(true);
            System.out.println("Returned successful");
            return true;
        }
        else return false;
    }

    public static int calculateFine(int daysOverdue){
        int tax=daysOverdue*2;
        System.out.println("the total charge is :"+tax);
        return tax;
    }

    public static int calculateFine(int daysOverdue,boolean isMemberVIP){
        int tax=daysOverdue*2;
        if(isMemberVIP){
            tax/=2;
        }
        System.out.println("the total charge is :"+tax);
        return tax;
    }

    public Book[] search(String value){
        boolean isSubstring=true;
        Book[] books=new Book[100];
        int idx=0;
        for(int i=0;i<Book.nrOfBooks;i++)
        {
            if(Book.allBooks[i]!=null) {
                isSubstring =Book.allBooks[i].getTitle().toLowerCase().contains(value.toLowerCase());
                if(isSubstring)
                {
                    books[idx++]=Book.allBooks[i];
                }
            }
        }
        return books;
    }


}
