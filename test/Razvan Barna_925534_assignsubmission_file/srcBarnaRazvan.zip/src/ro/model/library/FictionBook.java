package ro.model.library;

public class FictionBook extends Book{
    private String genre;

    public FictionBook(String title, String ISBN, boolean isAvailable, String genre) {
        super(title, ISBN, isAvailable);
        this.genre = genre;
    }

   public void displayDetails(){
        super.displayDetails();
        System.out.println("the genre of this fiction book is "+genre);
    }


}
