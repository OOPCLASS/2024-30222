package ro.model.library;

import java.time.LocalDate;

public class Book {
    private String title;
    private String ISBN;
    private boolean isAvailable;
    public static int nrOfBooks=0;
    public static Book[] allBooks=new Book[100];

    public Book(String title, String ISBN, boolean isAvailable) {
        this.title = title;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
        allBooks[nrOfBooks] = this;
        nrOfBooks++;
    }

    public static void displayLibrary() {
        for (int i = 0; i < nrOfBooks; i++) {
            allBooks[i].displayDetails();
        }
    }

    public boolean checkAvailability(){
        return this.isAvailable;
    }

    public void displayDetails(){
        System.out.println("the title is "+title+" ISBN is "+ISBN+" and it's availability is "+isAvailable);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }


}
