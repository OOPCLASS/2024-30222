package ro.model.member;

import ro.model.library.Book;

public class Member {
    private String name;
    private int memberID;
    private Book[] loanHistory=new Book[10];
    public int nrOfLoans=0;
    public static int nrOfMembers=0;
    public static Member[] allmembers=new Member[10];

    public void addLoan(Book b){
        loanHistory[nrOfLoans]=b;
        nrOfLoans++;
    }

    public Member(int memberID, String name) {
        this.memberID = memberID;
        this.name = name;
        allmembers[nrOfMembers]=this;
        nrOfMembers++;
    }

    public Member(int memberID, String name,Book b1){
        this.memberID=memberID;
        this.name=name;
        loanHistory[0]=b1;
        allmembers[nrOfMembers]=this;
        nrOfMembers++;
    }

    public static void displayMembers() {
        for (int i = 0; i < nrOfMembers; i++) {
            allmembers[i].displayInfo();
        }
    }

    public void displayInfo(){
        System.out.println("name: "+name+" ,memberID "+memberID+" and the loans are: ");
        for(Book b: loanHistory){
            if(b!=null){
                b.displayDetails();
            }
        }
    }

}
