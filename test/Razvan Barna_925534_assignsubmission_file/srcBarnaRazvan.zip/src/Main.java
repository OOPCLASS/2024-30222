import ro.model.library.Book;
import ro.model.member.Member;

public class Main {
    public static void main(String[] args) {

    }
}