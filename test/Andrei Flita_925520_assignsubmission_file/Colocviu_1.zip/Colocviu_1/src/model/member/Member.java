package model.member;

import java.util.ArrayList;
import java.util.List;

public class Member {
    private final String name;
    private final int memberID;
    private final List<String> loanHistory;

    public Member(String name, int memberID) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>();
    }

    public Member(String name, int memberID, List<String> loanHistory) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = loanHistory;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Member ID: " + memberID);
        System.out.println("Loan History: " + loanHistory);
    }

    public void addLoanHistory(String bookTitle) {
        loanHistory.add(bookTitle);
    }
}

