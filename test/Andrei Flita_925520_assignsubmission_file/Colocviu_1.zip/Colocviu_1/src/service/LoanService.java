package service;

import model.library.Book;
import model.member.Member;

import java.util.ArrayList;
import java.util.List;

public class LoanService {
    private final List<Book> bookCatalog = new ArrayList<>();

    public String loanBook(Book book, Member member) {
        if (book.checkAvailability()) {
            book.setAvailability(false);
            member.addLoanHistory(book.getTitle());
            return "Loan successful!";
        } else {
            return "Book not available for loaning.";
        }
    }

    public boolean returnBook(Book book) {
        if (!book.checkAvailability()) {
            book.setAvailability(true);
            return true;
        }
        return false;
    }

    public static int calculateFine(int daysOverdue) {
        return daysOverdue * 2;
    }

    public static int calculateFine(int daysOverdue, boolean isMemberVIP) {
        int fine = calculateFine(daysOverdue);
        return isMemberVIP ? fine / 2 : fine;
    }

    public Book[] search(String value) {
        List<Book> result = new ArrayList<>();
        for (Book book : bookCatalog) {
            if (book.getTitle().toLowerCase().contains(value.toLowerCase()) ||
                    book.getAuthor().toLowerCase().contains(value.toLowerCase())) {
                result.add(book);
            }
        }
        return result.toArray(new Book[0]);
    }

    public void addBookToCatalog(Book book) {
        bookCatalog.add(book);
    }
}
