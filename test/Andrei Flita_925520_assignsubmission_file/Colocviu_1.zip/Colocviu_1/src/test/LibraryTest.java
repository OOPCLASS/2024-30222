package test;

import model.library.*;
import model.member.Member;
import service.LoanService;

import java.util.ArrayList;

public class LibraryTest {
    public static void main(String[] args) {

        FictionBook fb1 = new FictionBook("Harry Potter", "J.K. Rowling", "12345", true, "Fantasy");
        NonFictionBook nfb1 = new NonFictionBook("The Selfish Gene", "Richard Dawkins", "67890", true, "Science");


        Member member1 = new Member("Alice", 1);
        Member member2 = new Member("Bob", 2, new ArrayList<>());


        LoanService loanService = new LoanService();
        loanService.addBookToCatalog(fb1);
        loanService.addBookToCatalog(nfb1);


        System.out.println(loanService.loanBook(fb1, member1));
        System.out.println(loanService.loanBook(fb1, member2));
        System.out.println(loanService.loanBook(nfb1, member2));

        System.out.println("Returning book: " + loanService.returnBook(fb1));


        System.out.println("Fine for 3 days overdue: $" + LoanService.calculateFine(3)); // $6
        System.out.println("VIP Fine for 3 days overdue: $" + LoanService.calculateFine(3, true)); // $3
        System.out.println("Fine for 7 days overdue: $" + LoanService.calculateFine(7));

        Book[] searchResults = loanService.search("harry");
        for (Book book : searchResults) {
            book.displayDetails();
        }
        Book[] searchResults2 = loanService.search("gene");
        for (Book book : searchResults2) {
            book.displayDetails();
        }

        member1.displayInfo();
        member2.displayInfo();
        fb1.displayDetails();
        nfb1.displayDetails();
    }
}
