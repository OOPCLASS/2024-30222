package model.library;

import java.util.ArrayList;
import java.util.List;

public class Book {
    private String title;
    private String author;
    private String ISBN;
    private boolean isAvailable;
    private List<String> loanHistory; 

    public Book(String title, String author, String ISBN, boolean isAvailable) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
        this.loanHistory = new ArrayList<>();
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void loan(String memberName) {
        isAvailable = false;
        loanHistory.add(memberName);
    }

    public void returnBook() {
        isAvailable = true;
    }

    public List<String> getLoanHistory() {
        return loanHistory;
    }


    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    
    public String getISBN() {
        return ISBN;
    }


    public boolean getIsAvailable() {
        return isAvailable;
    }

    public void displayDetails() {
        System.out.println("Title: " + title + ", Author: " + author + ", ISBN: " + ISBN + ", Available: " + isAvailable);
    }
}