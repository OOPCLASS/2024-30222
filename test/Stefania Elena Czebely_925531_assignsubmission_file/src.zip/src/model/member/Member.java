package model.member;

import java.util.ArrayList;
import java.util.List;

public class Member {
    private String name;
    private String memberId;
    private boolean isVIP;
    private List<String> loanHistory; 

    public Member(String name, String memberId, boolean isVIP) {
        this.name = name;
        this.memberId = memberId;
        this.isVIP = isVIP;
        this.loanHistory = new ArrayList<>();
    }


    public void addLoanHistory(String bookTitle) {
        loanHistory.add(bookTitle);
    }

    public List<String> getLoanHistory() {
        return loanHistory;
    }

    public boolean isVIP() {
        return isVIP;
    }

    public void displayInfo() {
        System.out.println("Name: " + name + ", Member ID: " + memberId);
        System.out.println("Loan History: " + loanHistory);
    }


	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
}