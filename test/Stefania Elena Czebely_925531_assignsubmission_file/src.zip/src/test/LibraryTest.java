package test;

import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;

import java.time.LocalDate;

public class LibraryTest {
    public static void main(String[] args) {
        FictionBook book1 = new FictionBook("Micul Print", "Antoine de Saint-Exupery", "1943", true, "Fiction");
        NonFictionBook book2 = new NonFictionBook("Istoria Romaniei", "Gheorghe I.Bratianu", "1989", true, "History NonFinction  ");

        Member member1 = new Member("Iulia", "M001", false);
        Member member2 = new Member("Andrei", "M002", true);

        LoanService loanService = new LoanService();


        loanService.loanBook(book1, member1);


        loanService.loanBook(book1, member2);


        loanService.returnBook(book1, member1, LocalDate.now().minusDays(3));

        System.out.println();
        book1.displayDetails();
        book2.displayDetails();

        System.out.println();
        member1.displayInfo();
        member2.displayInfo();

        if (book1.getTitle().equals("Micul Print")) {
            System.out.println("\nSearch Results:");
            book1.displayDetails();
        }
    }
}