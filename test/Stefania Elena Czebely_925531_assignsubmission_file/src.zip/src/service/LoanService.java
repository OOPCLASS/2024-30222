package service;

import model.library.Book;
import model.member.Member;

import java.time.LocalDate;

public class LoanService {

    public boolean loanBook(Book book, Member member) {
        if (book.isAvailable()) {
            book.loan(member.getName());
            member.addLoanHistory(book.getTitle());
            System.out.println("Loaning successful");
            return true;
        } else {
            System.out.println("Book not available for loaning");
            return false;
        }
    }

    public void returnBook(Book book, Member member, LocalDate loanDate) {
        book.returnBook();

        LocalDate currentDate = LocalDate.now();
        int daysOverdue = currentDate.getDayOfYear() - loanDate.getDayOfYear();

        if (daysOverdue > 2) {
            double fine = calculateFine(daysOverdue, member.isVIP());
            System.out.println("Fine: $" + fine);
        }
    }

    public static double calculateFine(int daysOverdue, boolean isVIP) {
        double fine = daysOverdue * 2;  
        if (isVIP) {
            fine *= 0.5; 
        }

        return fine;
    }
}