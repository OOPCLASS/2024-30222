package service;
import java.util.ArrayList;
import java.util.List;

import model.library.Book;
import model.member.Member;

public class LoanService {
    protected List<Book> books;

    public LoanService(List<Book> books) {
        this.books = books;
    }

    public String loanBook(Book book, Member member) {
        if (!book.checkAvailability())
            return "Book is not available for loaning.";
      book.isAvailable=false;
      member.loanHistory.add(book.title);
      return "Loaning successful";

    }

    public boolean returnBook(Book book) {
        if (book.checkAvailability()) {
            return false;
        }

        book.isAvailable = true;
        return true;
    }

    public static final int FINE = 2;
    public static final double FINE_VIP =0.5;

    public static int calculateFine(int daysOverdue) {
        return daysOverdue * FINE;
    }

    public static int calculateFine(int daysOverdue, boolean isMemberVIP) {
        int fine = daysOverdue * FINE;

        if (isMemberVIP) {
            fine = (int) (fine * FINE_VIP);
        }

        return fine;
    }


    public Book[] search(String value) {
        List<Book> foundBooks = new ArrayList<>();

        for (Book book : books) {
            if (book.title.toLowerCase().contains(value.toLowerCase()) || book.author.toLowerCase().contains(value.toLowerCase()))
            {
                foundBooks.add(book);
            }
        }
        return foundBooks.toArray(new Book[0]);
    }

}



