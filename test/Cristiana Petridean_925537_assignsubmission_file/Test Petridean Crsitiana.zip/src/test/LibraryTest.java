package test;

import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;

import java.util.ArrayList;
import java.util.List;


public class LibraryTest {
        public static void main(String[] args) {

            Book book1 = new Book("Jane Eyre", "Bronte", 1234, true);
            book1.checkAvailability();
            book1.displayDetails();

            System.out.println("");

            FictionBook book2 = new FictionBook("Ion", "Liviu Rebreanu", 1233, false, "Romance");
            book2.checkAvailability();
            book2.displayDetails();

            System.out.println("");
            NonFictionBook book3 = new NonFictionBook("The Art of Consent", "Joseph Triuee", 2344, true, "Psychology");
            book3.displayDetails();
            System.out.println("");

            Member member1 = new Member("Johanna", "1994");
            member1.DisplayInfo();
            System.out.println("");
            List<String> loans = new ArrayList<>();
            loans.add("Hunger Games");
            loans.add("The Witcher");

            Member member2 = new Member("Cristiana", "1845", loans);
            member2.DisplayInfo();
            System.out.println("");

            Book book4 = new Book("Pride and Prejudice", "Jane Austen", 12345, true);
            Book book5 = new Book("The Portrait of Dorian Gray", "Oscar Wilde", 67890, true);

            List<Book> books = new ArrayList<>();
            books.add(book4);
            books.add(book5);

            LoanService loanService = new LoanService(books);

            Member member3 = new Member("Mary", "12345");
            System.out.println(loanService.loanBook(book4, member3));

            System.out.println("");

            System.out.println(loanService.loanBook(book4, member3));

            System.out.println("");

            System.out.println(loanService.returnBook(book4));

            System.out.println("");

            System.out.println(loanService.returnBook(book4));

            System.out.println("");

            System.out.println("Fine for 6 days overdue: " + LoanService.calculateFine(6));

            System.out.println("");

            Book[] searchResults = loanService.search("Pride");
            System.out.println("Search results for 'Pride':");
            for (Book b : searchResults) {
                b.displayDetails();
            }
        }

}
