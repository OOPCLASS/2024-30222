package model.member;
import java.util.ArrayList;
import java.util.List;

public class Member {
    public String name;
    public String memberID;
    public List<String> loanHistory;

    public Member(String name, String memberID) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>();
    }

    public Member(String name, String memberID, List<String> loanHistory) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = loanHistory != null ? new ArrayList<>(loanHistory) : new ArrayList<>();
    }

    public void DisplayInfo(){
       System.out.println("Name: " + name);
       System.out.println("Member ID: " + memberID);
       System.out.println("Loan History: " + loanHistory);
    }
}
