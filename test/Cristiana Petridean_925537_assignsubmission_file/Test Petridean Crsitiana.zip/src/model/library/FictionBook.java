package model.library;


public class FictionBook extends Book {
     public FictionBook() {};
     public String genre;
     public FictionBook(String title, String author,int ISBN,boolean isAvailable,String genre) {
         super(title,author,ISBN,isAvailable);
         this.genre = genre;

     }

    public void displayDetails() {
        super.displayDetails();
        System.out.println("Genre: " + genre);
    }
}
