package model.library;

public class Book {
    public String title;
    public String author;
    public int ISBN;
    public boolean isAvailable;

    public Book() {
 this.title = "Null";
 this.author = "Null";
 this.ISBN = 0;
 this.isAvailable = false;
    }

    public Book(String title, String author, int ISBN, boolean isAvailable) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
    }
     public void displayDetails() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("ISBN: " + ISBN);
        System.out.println("Available: " + isAvailable);

     }

     public boolean checkAvailability() {
        if(isAvailable) {return true;}

        else {return false;}
     }

}
