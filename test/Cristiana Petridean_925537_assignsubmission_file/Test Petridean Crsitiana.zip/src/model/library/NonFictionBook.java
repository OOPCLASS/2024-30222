package model.library;

public class NonFictionBook extends Book {
   public String fieldOfStudy;


    public NonFictionBook(String title, String author, int isbn,boolean isAvailabile, String fieldOfStudy) {
        super(title, author, isbn, isAvailabile);
        this.fieldOfStudy=fieldOfStudy;
    }

    public void displayDetails() {
        super.displayDetails();
        System.out.println("Field of study: " + fieldOfStudy);
    }
}
