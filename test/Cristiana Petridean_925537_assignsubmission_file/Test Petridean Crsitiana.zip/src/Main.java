import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;
import model.library.Book;
import model.library.FictionBook;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
     /*  Book book1=new Book("Jane Eyre","Jane Austen", 1234,true);
        book1.checkAvailability();
        book1.displayDetails();


        FictionBook book2=new FictionBook("Ion","Liviu Rebreanu", 1233,false,"Romance");
        book2.checkAvailability();
        book2.displayDetails();


        NonFictionBook book3 = new NonFictionBook("The art of consent","Joseph Triuee",2344,true,"Psychology");
        book3.displayDetails();



        Member member1=new Member("Johanna","1994");
        member1.DisplayInfo();

        List<String> loans = new ArrayList<>();
        loans.add("Hunger Games");
        loans.add("The Witcher");

        Member member2=new Member("Johanna","1995",loans);
        member2.DisplayInfo();




        Book book1 = new Book("Pride and Prejudice", "Austen", 12345, true);
        Book book2 = new Book("The portrait of Dorian Grey", "Oscar Wilde", 67890, true);


        List<Book> books = new ArrayList<>();
        books.add(book1);
        books.add(book2);

        LoanService loanService = new LoanService(books);

        Member member = new Member("Mary", "12345");

        System.out.println(loanService.loanBook(book1, member));
        System.out.println(loanService.loanBook(book1, member));

        System.out.println(loanService.returnBook(book1));

        System.out.println(LoanService.calculateFine(6));

        Book[] searchResults = loanService.search("book");
        for (Book b : searchResults) {
            b.displayDetails();
        }
    }

       */

    }
}
