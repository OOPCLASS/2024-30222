package service;

import model.library.Book;
import model.member.Member;
import java.util.ArrayList;
import java.util.List;

public class LoanService {

    public Book book;
    public Member member;
    public boolean loaned;

    public LoanService(Book book, Member member, boolean loaned) {
        this.book = book;
        this.member = member;
        this.loaned = loaned;
    }

    String loanBook(Book book, Member member) {
        if (book.isAvailable()) {
            loaned = true;
            member.getLoanHistory(book);
            return "Loaning successful.";
        } else return "Book not available for loaning.";
    }

    public boolean returnBook(Book book) {
        if (!book.isAvailable()) {
            loaned = false;
            return true;
        } else return false;
    }

    public static int calculateFine(int daysOverdue) {
        int finePerDay = 2;
        return daysOverdue * finePerDay;
    }

    private List<Book> books = new ArrayList<>();
    public void addBook(Book book) {
        books.add(book);
    }

    public Book[] search(String value) {
        List<Book> matchingBooks = new ArrayList<>();
        String searchValue = value.toLowerCase();

        for (Book book : books) {

            if (book.getTitle().toLowerCase().contains(searchValue) || book.getAuthor().toLowerCase().contains(searchValue)) {
                matchingBooks.add(book);
            }
        }
        return matchingBooks.toArray(new Book[0]);
    }
}