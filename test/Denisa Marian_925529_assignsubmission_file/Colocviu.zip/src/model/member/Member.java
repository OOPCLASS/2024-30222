package model.member;

import model.library.Book;

public class Member {
    public String name;
    public int memberid;
    private String loanHistory;

    public Member(String name, int memberid, String loanHistory) {
        this.name = name;
        this.memberid = memberid;
        this.loanHistory = loanHistory;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMemberid() {
        return memberid;
    }

    public void setMemberid(int memberid) {
        this.memberid = memberid;
    }

    public String getLoanHistory(Book book) {
        return loanHistory;
    }

    public void setLoanHistory(String loanHistory) {
        this.loanHistory = loanHistory;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("MemberID: " + memberid);
        System.out.println("LoanHistory: " + loanHistory);
    }

    public void memberInfo(String name, int memberid) {
        this.name = name;
        this.memberid = memberid;
    }

    public void memberInfo(String name, int memberid, String loanHistory) {
        this.name = name;
        this.memberid = memberid;
        this.loanHistory = loanHistory;
    }

}
