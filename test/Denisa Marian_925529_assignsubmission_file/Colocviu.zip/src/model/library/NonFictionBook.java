package model.library;

public class NonFictionBook extends Book {
    public String fieldOfStudy;

    public NonFictionBook(String title, String author, int ISBN, boolean isAvailable, String fieldOfStudy) {
        super(title, author, ISBN, isAvailable);
        this.fieldOfStudy = fieldOfStudy;
    }

    public String getFieldOfStudy() {
        return fieldOfStudy;
    }

    public void setFieldOfStudy(String fieldOfStudy) {
        this.fieldOfStudy = fieldOfStudy;
    }

    public void displayDetails(){
        super.displayDetails();
        System.out.println("Field of study: " + fieldOfStudy);
    }
}
