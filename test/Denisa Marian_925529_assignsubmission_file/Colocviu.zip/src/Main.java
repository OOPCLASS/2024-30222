import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;
import test.Test;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
         Book book = null;
         Member member = null;
         FictionBook fictionBook;
         NonFictionBook nonFictionBook;
         LoanService loanService;
         Test test = null;

        
            loanService = new LoanService(book, member, true);
            book = new Book("Fictional Story", "Author A", 123, true);
            fictionBook = new FictionBook("Fictional Story", "Author B", 234, true, "romance");
            nonFictionBook = new NonFictionBook("Non-Fictional Facts", "Author C", 345, true, "math");
            loanService.addBook(fictionBook);
            loanService.addBook(nonFictionBook);
            member = new Member("deni", 113, "gol");
        
            book.displayDetails();
            fictionBook.displayDetails();
            nonFictionBook.displayDetails();
            test.testSearchBooks();
            test.testCalculate();

    }
}