package test;

import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;

public class Test {
    private Book book;
    private Member member;
    private FictionBook fictionBook;
    private NonFictionBook nonFictionBook;
    private LoanService loanService;

    public void setUp() {
        loanService = new LoanService(book, member, true);
        book = new Book("Fictional Story", "Author A", 123, true);
        fictionBook = new FictionBook("Fictional Story", "Author B", 234, true, "romance");
        nonFictionBook = new NonFictionBook("Non-Fictional Facts", "Author C", 345, true, "math");
        loanService.addBook(fictionBook);
        loanService.addBook(nonFictionBook);
        member = new Member("deni", 113, "gol");
    }

    public void testCalculate() {
        int daysOverdue = 5;
        int fine = loanService.calculateFine(daysOverdue);
        System.out.println("Fine for " + daysOverdue + " days overdue: $" + fine);
    }

    public void testSearchBooks() {
        Book[] results = loanService.search("Facts");
        System.out.println("Search: " + results[0]);

    }

}
