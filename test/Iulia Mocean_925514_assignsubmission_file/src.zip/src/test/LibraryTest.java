package test;

import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;

import java.util.List;

public class LibraryTest {
    public static void main(String[] args) {
        Book b1 = new FictionBook("Enigma Otiliei", "George Calinescu", "12", true, "Realism");
        Book b2 = new NonFictionBook("Istoria Romanilor", "Nicolae Iorga", "34", true, "Istorie");
        b1.displayDetails();
        b2.displayDetails();

        Member m1 = new Member("Maria", "32345");
        Member m2 = new Member("Larisa", "32346", List.of("Enigma Otiliei"));
        m1.displayInfo();
        m2.displayInfo();

        //imprumutare si disponibilitate
        LoanService serv = new LoanService();
        System.out.println("Cartea " + b1.getTitle() + ": " + serv.loanBook(b1, m1));
        System.out.println(m2.getName() + " imprumuta cartea " + b1.getTitle() + ": "  + serv.loanBook(b1, m2));

        //returnare si imprumutare dupa
        System.out.println(b1.getTitle()+ " retur: " + serv.returnBook(b1));
        System.out.println(m2.getName()+ " imprumuta cartea " + b1.getTitle() + ": "  + serv.loanBook(b1, m2));

        //plata intarziata
        System.out.println("Abonamnt Normal: 10 zile restante plata: " + LoanService.calculateFine(10));
        System.out.println("Abonament VIP: 10 zile restante plata: " + LoanService.calculateFine(10, true));

        // Cautare carti
        Book[] searchResults = serv.search("timp", new Book[]{b1, b2});
        System.out.println("Rezultat Cautare:");
        for (Book b : searchResults) {
            b.displayDetails();
        }
    }
}