package model.library;

public class Book {
    private String title;
    private String author;
    private String ISBN;
    private boolean isAvailable;

    // Constructor
    public Book(String title, String author, String ISBN, boolean isAvailable) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
    }

    // Methods
    public void displayDetails() {
        System.out.println("Titlu: " + title);
        System.out.println("Autor: " + author);
        System.out.println("International Standard Book Number: " + ISBN);
        System.out.println("Valabilitate: " + (isAvailable ? "DA" : "NU"));
    }

    public boolean checkAvailability() {
        return isAvailable;
    }

    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getISBN() {
        return ISBN;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

}
