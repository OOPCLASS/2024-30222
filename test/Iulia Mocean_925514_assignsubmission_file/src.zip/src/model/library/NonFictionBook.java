package model.library;

public class NonFictionBook extends Book {
    private String fieldOfStudy;

    public NonFictionBook(String title, String author, String ISBN, boolean isAvailable, String fieldOfStudy) {
        super(title, author, ISBN, isAvailable);
        this.fieldOfStudy = fieldOfStudy;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Camp de studiu: " + fieldOfStudy);
    }
}
