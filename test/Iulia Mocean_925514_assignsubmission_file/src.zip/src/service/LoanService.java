package service;

import model.library.Book;
import model.member.Member;

public class LoanService {
        public String loanBook(Book book, Member member) {
            if (!book.checkAvailability()) {
                return "Cartea nu este valabila momentan.";
            }
            book.setAvailable(false);
            member.addLoan(book.getTitle());
            return "Imprumut efectuat";
        }

        public boolean returnBook(Book book) {
            if (!book.isAvailable()) {
                book.setAvailable(true);
                return true;
            }
            return false;
        }

        public static int calculateFine(int daysOverdue) {
            return daysOverdue * 2;
        }

        public static int calculateFine(int daysOverdue, boolean isMemberVIP) {
            int fine = calculateFine(daysOverdue);
            return isMemberVIP ? fine / 2 : fine;
        }

        public Book[] search(String value, Book[] books) {
            return java.util.Arrays.stream(books)
                    .filter(book -> book.getTitle().toLowerCase().contains(value.toLowerCase())
                            || book.getAuthor().toLowerCase().contains(value.toLowerCase()))
                    .toArray(Book[]::new);
        }
    }
