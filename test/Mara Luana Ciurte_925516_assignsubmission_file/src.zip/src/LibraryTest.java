//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import model.library.*;
import model.member.Member;
import service.LoaningService;

public class LibraryTest {
    public static void main(String[] args) {
        Book[] books = new Book[10];
        LoaningService loaningService = new LoaningService();

        books[0]= new FictionBook("The magus", "John Fowles", "A210BS", "fantasy");
        books[1]= new FictionBook("Anna Karenina", "Lev Tolstoi", "JH67", "family");
        books[2]= new NonFictionBook("Evrika", "many authors", "KJH12", "science" );
        books[3]= new NonFictionBook("Why we sleep", "Mathew Walker","43FH", "science");

        Member[] members = new Member[10];

        Book[] loanedBooks = new Book[10];
        loanedBooks[0] = books[1];
        Book[] loanedbooksbyJohn = new Book[10];
        loanedbooksbyJohn[0] = books[0];

        members[0] = new Member("Mara", 2, loanedBooks);
        members[1] = new Member("John", 3, loanedbooksbyJohn);
        members[2] = new Member("Jane", 4);

        String status = loaningService.loanBook(books[3], members[0]);
        System.out.println(status);

        status = loaningService.loanBook(books[3], members[1]);
        System.out.println(status);

        status = loaningService.loanBook(books[0], members[1]);
        System.out.println(status);

        if(books[0].checkAvailability())
            System.out.println("The book '" + books[0].getTitle() +"' is available");
        else System.out.println("The book '" + books[0].getTitle() +"' is not available");

        loaningService.returnBook(books[0]);

        if(books[0].checkAvailability())
            System.out.println("The book '" + books[0].getTitle() +"' is available");
        else System.out.println("The book '" + books[0].getTitle() +"' is not available");

        System.out.println("Fine:" + loaningService.calculateFine(20) );
        System.out.println("Fine:" + loaningService.calculateFine(30, true));

//        for(Book book: books)
//        {
//            if (book instanceof FictionBook) {
//                System.out.println(((FictionBook) book).displayDetails());
//            else
//                System.out.println(((NonFictionBook) book).displayDetails());
//            }
//        }
    }
}