package service;
import model.library.*;
import model.member.Member;

public class LoaningService {

    int nr=0;

    public String loanBook(Book book, Member member) {
        if(book.checkAvailability()){
            book.setAvailability(false);
            nr++;
            Book[] loan = member.getLoanHistory();
            member.updateLoanHistory(member.getLoanHistory(), book.getTitle(), nr);
            return "Loaning successful";
        }
        return "Book is not available for loaning";
    }

    public boolean returnBook(Book book){
        book.setAvailability(true);
        return book.checkAvailability();
    }

    public static int calculateFine(int daysOverdue){
        if(daysOverdue>0)
            return daysOverdue * 2;
        return 0;
    }

    public static int calculateFine(int daysOverdue, boolean VIP){
        if(VIP && daysOverdue>0)
            return daysOverdue;
        else return calculateFine(daysOverdue);
    }

    public Book[] search(String value, Book[] books){
        Book[] foundBooks = new Book[books.length];
        int i=0;
        for( Book book : books){
            if(book.getTitle().toLowerCase().contains(value.toLowerCase())){
                foundBooks[i++] = new Book(book.getTitle());
            }
            else if(book.getAuthor().toLowerCase().contains(value.toLowerCase())){
                foundBooks[i++] = new Book(book.getAuthor());
            }
        }
        return foundBooks;
    }


}
