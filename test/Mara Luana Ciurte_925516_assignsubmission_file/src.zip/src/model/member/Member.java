package model.member;
import model.library.Book;

public class Member {
    private String name;
    private int memberID;
    private Book[] loanHistory;

    public Member(String name, int memberID) {
        this.name = name;
        this.memberID = memberID;
    }

    public Member(String name, int memberID, Book[] loanHistory) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = loanHistory;
    }

    public void updateLoanHistory(Book[] loanHistory, String name, int nr) {
        loanHistory[nr]=new Book(name);
    }

    public Book[] getLoanHistory() {
        return loanHistory;
    }


    void displayInfo(){
        System.out.println("Name: " + name);
        System.out.println("Member ID: " + memberID);
        System.out.print("Loan History: ");
        if(loanHistory != null){
            for(Book book: loanHistory)
                System.out.print(book + " ");
            System.out.println();
        }
        else System.out.println("No loan history available");
    }

}
