package model.library;

public class NonFictionBook extends Book {
    private String fieldOfStudy;

    public NonFictionBook(){};

    public NonFictionBook(String title, String author, String ISBN, String fieldOfStudy) {
        super(title, author, ISBN);
        this.fieldOfStudy = fieldOfStudy;
    }
    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Field of study: " + fieldOfStudy);
    }
    public String getFieldOfStudy() {
        return fieldOfStudy;
    }

    public void setFieldOfStudy(String fieldOfStudy) {
        this.fieldOfStudy = fieldOfStudy;
    }
}
