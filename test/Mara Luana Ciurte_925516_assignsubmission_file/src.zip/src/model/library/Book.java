package model.library;
import service.LoaningService;
import java.sql.SQLOutput;

public class Book {
    private String title;
    private String author;
    private String ISBN;
    private boolean isAvailable;

    public Book(){}

    public Book(String title, String author, String ISBN) {
        int i=0;
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
       // addToLibrary(title, library, i++);
        setAvailability(true);
    }
    public Book(String title){
        this.title = title;
    }

    public void displayDetails() {
        System.out.println("ISBN: " + ISBN);
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Available: " + isAvailable);
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setTitle(String title, Book[] library, int i) {
        this.title = title;
        addToLibrary(title, library, i++);
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public boolean checkAvailability() {
        return isAvailable;
    }

    public void setAvailability(boolean status){
        this.isAvailable = status;
    }

    public void addToLibrary(String title, Book[] library, int idx) {
         library[idx].setTitle(title);
    }
}
