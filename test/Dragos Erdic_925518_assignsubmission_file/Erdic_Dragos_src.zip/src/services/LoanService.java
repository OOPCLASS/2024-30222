package services;

import java.util.ArrayList;

import model.library.Book;
import model.member.LibraryMember;

public class LoanService {

	
	//– Marks the book as available again. Return true if operation
	//was successful.
	
	ArrayList<Book> theBooks;
	ArrayList<LibraryMember> theMembers;
	public LoanService(ArrayList<Book> theBooks, ArrayList<LibraryMember> theMembers ) {
		this.theBooks = theBooks;
		this.theMembers = theMembers;
		
	}
	public static String loanBook(Book book, LibraryMember member) {
		if(book.checkAvailability() == true)
		{
			book.setIsAvailable(false);
			member.loanBook(book);
			return "loaning successful";
		}
		return "book  not available for loaning";
		
	}
	
	public void deleteFromUsers(String ISBN) {
		for(int i = 0; i < theMembers.size(); i++) {
			
			for(int j = 0; j < theMembers.get(i).loanHistory.size(); j++) {
				if(theMembers.get(i).loanHistory.get(j).getISBN().equals(ISBN))
					theMembers.get(i).loanHistory.remove(j);
			}
		}
	}
	
	public  boolean returnBook(Book book) {
		book.setIsAvailable(true);
		for(int i = 0; i < theBooks.size(); i++) {
			if(book.getISBN().equals(theBooks.get(i).getISBN())){
				// have same isbn code
				theBooks.get(i).setIsAvailable(true);
				// normally we would delete from the each user this book, as it is free now
				this.deleteFromUsers(book.getISBN());
			}
		}
		return true;
	}
	
	public static int calculateFine(int daysOverdue) {
		return daysOverdue * 2;
		
	}
	public static int calculateFine(int daysOverdue, boolean isVip) {
		if(isVip == true)
			return daysOverdue;
		return calculateFine(daysOverdue);
		
	}
	/*
	 * mplement a search method for books that looks into all created
books and return and array of Book objects that have the title or author containing the searched
value ignoring letter case (for example searching for "book" should match books with title: "My
book", "Booklet")
	 * */
	public ArrayList<Book> search(String value){
		ArrayList<Book> returnedList = new ArrayList<Book>();
		
		for(int i = 0; i < theBooks.size(); i++) {
			if(theBooks.get(i).getTitle().toLowerCase().indexOf(value) != -1 
					|| theBooks.get(i).getAuthor().toLowerCase().indexOf(value) != -1)
					returnedList.add(theBooks.get(i));
		}
		
		
		return returnedList;
	}
}
