package tests;

import java.util.ArrayList;

import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.LibraryMember;
import services.LoanService;

public class TestLibrary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Book> arrInstante = new ArrayList<Book>();
		arrInstante.add(new FictionBook("Aventurile lui Tom Sawyer", "Nu mai stiu", "0733", true, "copilarie"));
		arrInstante.add(new Book("Aventurile", "Nu mai stiu", "11183", true));
		arrInstante.add(new NonFictionBook("Maturile lui Tom Sawyer", "Moldovean", "7734", true, "Lemnul, proprietati"));
		arrInstante.add(new FictionBook("Mancarea lui Tom Sawyer", "Ardelean", "225", true, "macelarie"));
		arrInstante.add(new FictionBook("Ferma Animalelor", "George Orwell", "22345", true, "societate"));

		ArrayList<Book> arrM1 = new ArrayList<Book>();
		arrM1.add(arrInstante.get(0));
		arrM1.add(arrInstante.get(3));
		ArrayList<Book> arrM2 = new ArrayList<Book>();
		arrM2.add(arrInstante.get(1));
		arrM2.add(arrInstante.get(2));
		LibraryMember m1 = new LibraryMember("Marculet", "074e3");
		
		// exista cazul in care eu dau carti deja rezervate, caz tratat
		LibraryMember m2 = new LibraryMember("Darius", "07753", arrM1);

		LibraryMember m3 = new LibraryMember("Campean", "0945", arrM2);
		

		ArrayList<LibraryMember> theList = new ArrayList<LibraryMember>();
		theList.add(m1);
		theList.add(m2);
		theList.add(m3);
		
		arrInstante.get(0).displayDetails();
		arrInstante.get(1).displayDetails();
		arrInstante.get(2).displayDetails();
		
		m2.loanBook(arrInstante.get(4));
		arrInstante.get(4).displayDetails();
		
		LoanService nou = new LoanService(arrInstante, theList);
		nou.returnBook(arrInstante.get(4));
		arrInstante.get(4).displayDetails();
		// cand returnez o carte, eu practic trebuie sa ii dau delete din lista celui care a luat-o
		// asta am facut-o
		
		System.out.println(LoanService.calculateFine(10));
		
		System.out.println(LoanService.calculateFine(10, true));
		System.out.println("\n");
		for(int i = 0; i < arrInstante.size(); i++) {
			// print book
			arrInstante.get(i).displayDetails();
		}
		System.out.println("\n");
		for(int i = 0; i < theList.size(); i++) {
			theList.get(i).displayInfo();
		}
		
		
	}

}
