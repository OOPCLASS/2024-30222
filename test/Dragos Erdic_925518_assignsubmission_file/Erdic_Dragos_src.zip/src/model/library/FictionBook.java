package model.library;

public class FictionBook extends Book {
	private String genre;
	public FictionBook(String title, String author, String ISBN, Boolean isAvailable, String genre) {
		super(title, author, ISBN, isAvailable);
		this.genre = genre;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	@Override
	public void displayDetails() {
		String availableInf = (this.checkAvailability() == true) ? "is available" : "is not available";
		System.out.println(this.getTitle() + " written by " + this.getAuthor() + " " + availableInf + " with the genre " + this.getGenre());
	}

}
