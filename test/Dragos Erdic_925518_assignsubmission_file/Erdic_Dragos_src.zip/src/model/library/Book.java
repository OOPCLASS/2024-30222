package model.library;

public class Book {
	private String title;
	private String author, ISBN;
	private Boolean isAvailable;
	public Book(String title, String author, String ISBN, Boolean isAvailable) {
		this.title = title;
		this.author = author;
		this.ISBN = ISBN;
		this.isAvailable = isAvailable;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Boolean getIsAvailable() {
		return isAvailable;
	}
	public void setIsAvailable(Boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	//– Displays the book’s information.
	public void displayDetails() {
		String availableInf = (isAvailable.equals(1)) ? "is available" : "is not available";
		System.out.println(this.title + " written by " + this.author + " " + availableInf);
	}
	 public boolean checkAvailability() {
		 return this.getIsAvailable();
	 }
	 
}
