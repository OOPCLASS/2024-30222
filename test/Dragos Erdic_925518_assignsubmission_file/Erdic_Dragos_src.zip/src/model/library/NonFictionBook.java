package model.library;

public class NonFictionBook extends Book {
	private String fieldOfStudy;
	
	public NonFictionBook(String title, String author, String ISBN, Boolean isAvailable, String fieldOfStudy) {
		super(title, author, ISBN, isAvailable);
		// TODO Auto-generated constructor stub
		this.fieldOfStudy = fieldOfStudy;
	}

	public String getFieldOfStudy() {
		return fieldOfStudy;
	}

	public void setFieldOfStudy(String fieldOfStudy) {
		this.fieldOfStudy = fieldOfStudy;
	}
	@Override
	public void displayDetails() {
		String availableInf = (this.checkAvailability() == true) ? "is available" : "is not available";
		System.out.println(this.getTitle() + " written by " + this.getAuthor() + " " + availableInf + " with the field " + this.getFieldOfStudy());
	}
}
