package model.member;

import java.util.ArrayList;

import model.library.Book;

public class LibraryMember {
	private String name;
	private String memberID;
	public ArrayList<Book> loanHistory;
	public LibraryMember(String name, String memberId) {
		this.setName(name);
		this.setMemberID(memberId);
		this.loanHistory = new ArrayList<Book>();
		
	}
	public LibraryMember(String name, String memberId, ArrayList<Book> initArr) {
		this.setName(name);
		this.setMemberID(memberId);
		loanHistory = new ArrayList<Book>();
		for(int i = 0; i < initArr.size(); i++) {
			if(initArr.get(i).checkAvailability() == true)
			{
			loanHistory.add(initArr.get(i));
			loanHistory.get(i).setIsAvailable(false);
			}
			// we add each initial book to the loanHistory
			// then we say it can't be used
		}
		
	}
	public void displayInfo() {
		System.out.println(name + " with id: " + memberID + "with the books:");
		for(int i = 0; i < this.loanHistory.size(); i++) {
			loanHistory.get(i).displayDetails();
		}
		
	}
	public void loanBook(Book newBook) {
		
		if(newBook.checkAvailability() == true)
		{
			newBook.setIsAvailable(false);
			loanHistory.add(newBook);
		}
		
		
	}
	
	public String getMemberID() {
		return memberID;
	}
	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
