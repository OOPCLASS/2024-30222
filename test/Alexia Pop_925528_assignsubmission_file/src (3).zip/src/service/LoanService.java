package service;
import model.library.Book;
import model.member.Member;

public class LoanService {
    static int numberOfBooks = 50;
    static Book allBooks[] = new Book[numberOfBooks];

    public LoanService() {}

    public String loanBook(Book book, Member member){
        //adaugam in istoricul membrului
        if(book.checkAvailability())
        {
            book.loaned();
            member.updateLoanHistory(book.getTitle());
            return "Loaning successful -> Book " + book.getTitle() + " is loaned by member: " + member.getName(); //actualizeaza
        }
        else {
            return "Book is not available for loaning";
        }

    }

    public boolean returnBook(Book book){
        //marcheaza cartea ca fiind valabila din nou
        book.returned();
        if(book.checkAvailability())
        {
            System.out.println("Returning was successful");
            return true;
        }
        else {
            System.out.println("Error - Return");
            return false;
        }
    }

    public static int calculateFine(int daysOverdue){
        return daysOverdue*2;
    }
    public static int calculateFine_VIP(int daysOverdue, boolean isVIP){
        return (daysOverdue*2 - ((daysOverdue*2) *5)/10);
    }

    public Book[] search(String value){
        int nrMatches = 0;
        Book foundMatches[] = new Book[nrMatches];
        for (Book book : allBooks) {
            if(book.getTitle().contains(value) || book.getAuthor().contains(value))
            {
                foundMatches[nrMatches++] = book; //am gasit o carte si o adaugam in lista
            }
            //if(book.getTitle().compareToIgnoreCase(value) == 0)
        }
        if(nrMatches != 0)
            return foundMatches;
        else {
            System.out.println("No matches found");
            return null;
        }
    }
}
