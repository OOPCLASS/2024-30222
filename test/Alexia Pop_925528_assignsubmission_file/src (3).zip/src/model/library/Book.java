package model.library;

public class Book {
    public String title;
    public String author;
    public String ISBN;
    public boolean isAvailable;

    public Book(){}
    public Book(String title, String author, String ISBN, boolean isAvailable) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
    }

    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }

    public void displayDetails(){
        System.out.println("Title: " + title + " Author: " + author + " ISBN: " + ISBN + " Available: " + isAvailable);
    }
    public boolean checkAvailability(){
        return isAvailable;
    }
    public void loaned(){this.isAvailable = false;}
    public void returned(){this.isAvailable = true;}
}
