package model.library;

public class NonFictionBook extends Book {
    private String fieldOfStudy;
    public NonFictionBook() {}

    public NonFictionBook(String title, String author, String ISBN, boolean isAvailable, String fieldOfStudy) {
        super(title,author,ISBN,isAvailable);
        this.fieldOfStudy = fieldOfStudy;
    }
    public void displayDetails(){
        System.out.println("Field of study: " + fieldOfStudy);
        System.out.println("Title: " + title + " Author: " + author + " ISBN: " + ISBN + " Available: " + isAvailable);
    }
}
