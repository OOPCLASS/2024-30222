package model.member;

public class Member {
    public String name;
    public int memberID;
    public int totalLoanedBooks;
    public String[] loanHistory = new String[5];
    public boolean VIP;


    public Member(){}

    public Member(String name, int memberID) {
        this.name = name;
        this.memberID = memberID;
    }
    public Member(String[] loanHistory) {
        this.loanHistory = loanHistory;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }
    public void setLoanHistory(String[] loanHistory) {
        this.loanHistory = loanHistory;
    }
    public void setVIP(boolean VIP) {
        this.VIP = VIP;
    }
    public boolean isVIP() {
        return VIP;
    }

    public String getName() {
        return name;
    }
    public void updateLoanHistory(String bookInfo){
        String updatedLoan = new String(bookInfo);
        loanHistory[totalLoanedBooks++] = updatedLoan;
    }

    public void displayInfo(){
        System.out.println("Name: " + name + " MemberID: " + memberID );
        System.out.println("with the following loan history: ");
        for (String i : loanHistory) {
            if(i != null)
            System.out.println(i);
        }
    }
    public void displayInfoWithoutLoaningHistory(){
        System.out.println("Name: " + name + " MemberID: " + memberID );
        System.out.println("with the following loan history: ");
    }

    public void displayLoaningInfo(){
        for (String i : loanHistory) {
            if(i != null)
            System.out.println(i);
        }
    }
}
