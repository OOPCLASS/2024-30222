import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;

public class Main {

    public static void main(String[] args) {

    }
}