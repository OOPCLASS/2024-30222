import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;

public class LibraryTest {
    public int calculatingFee(LoanService L, Member m, int daysLate)
    {
        int fee = 0;
        if(m.isVIP()) {
            System.out.print("VIP ");
            fee = L.calculateFine_VIP(daysLate,m.isVIP());
        }
        else
            fee = L.calculateFine(daysLate);
        return fee;
    }
    public static void main(String[] args) {
        Book b[] = new Book[3];

        b[0] = new Book("title", "book", "12324", true);
        b[1] = new FictionBook("title2", "book2", "12324", true,"Adventure");
        b[2] = new NonFictionBook("title3", "book3", "12324", true,"Science");

        String loan1[] = new String[2];
        loan1[0] = "title1";
        loan1[1] = "title2";

        Member m[] = new Member[3];
        m[0] = new Member("John", 12);
        m[1] = new Member(loan1);
        m[1].setName("Jane");
        m[1].setMemberID(13);

        m[2] = new Member("Mary", 14);

        LoanService L = new LoanService();
        System.out.println(L.loanBook(b[0],m[0]));
        L.returnBook(b[0]);
        //verificam valabilitatea cartii
        System.out.println("verificam valabilitatea cartii: ");
        System.out.println(b[0].checkAvailability());

        L.loanBook(b[0],m[0]);

        System.out.println("verificam istoricul clientului: ");
        m[0].displayLoaningInfo();

        LibraryTest _m = new LibraryTest();
        m[0].setVIP(true);
        int daysLate = 5;
        int fee = _m.calculatingFee(L,m[0],daysLate);
        System.out.println("Member: " + m[0].getName() + " has to pay a fee of: " + fee + " dollars");

        //System.out.println(L.loanBook(b[0],m[1]));
        System.out.println(L.loanBook(b[2],m[1]));
        daysLate = 10;
        fee = _m.calculatingFee(L,m[1],daysLate);
        System.out.println("Member: " + m[1].getName() + " has to pay a fee of: " + fee + " dollars");

        System.out.println(L.loanBook(b[0],m[1]));//cartea este deja imprumutata de membrul[0]

        int i=0;
        for (Member member : m) {
            System.out.print(i + " ");
            i++;
            member.displayInfo();
        }

        for (Book book : b) {
            book.displayDetails();
        }
    }
}
