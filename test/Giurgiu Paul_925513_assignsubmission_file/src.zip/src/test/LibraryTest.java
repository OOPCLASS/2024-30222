package test;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

import model.library.*;// *pentru a importa toate clasele din pachetul model.library
import model.member.*;
import service.LoanService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LibraryTest {
    public static void main(String[] args) {
        // facem cartile
        List<Book> bookCollection = new ArrayList<>();

        bookCollection.add(new FictionBook("1984", "George Orwell", "123456789", true, "Dystopian"));
        bookCollection.add(new FictionBook("Brave New World", "Aldous Huxley", "234567891", true, "Science Fiction"));
        bookCollection.add(new FictionBook("The Great Gatsby", "F. Scott Fitzgerald", "345678912", true, "Classic"));
        bookCollection.add(new FictionBook("To Kill a Mockingbird", "Harper Lee", "456789123", true, "Drama"));
        bookCollection.add(new FictionBook("The Hobbit", "J.R.R. Tolkien", "567891234", true, "Fantasy"));

        bookCollection.add(new NonFictionBook("A Brief History of Time", "Stephen Hawking", "987654321", true, "Science"));
        bookCollection.add(new NonFictionBook("Sapiens", "Yuval Noah Harari", "876543219", true, "History"));
        bookCollection.add(new NonFictionBook("Educated", "Tara Westover", "765432198", true, "Memoir"));
        bookCollection.add(new NonFictionBook("Becoming", "Michelle Obama", "654321987", true, "Autobiography"));
        bookCollection.add(new NonFictionBook("The Wright Brothers", "David McCullough", "543219876", true, "Biography"));

        bookCollection.add(new FictionBook("Harry Potter", "J.K. Rowling", "111122223", true, "Fantasy"));
        bookCollection.add(new FictionBook("Percy Jackson", "Rick Riordan", "222233334", true, "Adventure"));
        bookCollection.add(new FictionBook("Dune", "Frank Herbert", "333344445", true, "Science Fiction"));
        bookCollection.add(new NonFictionBook("The Art of War", "Sun Tzu", "444455556", true, "Strategy"));
        bookCollection.add(new NonFictionBook("Think and Grow Rich", "Napoleon Hill", "555566667", true, "Self-help"));

        // afisam toate cartile
        System.out.println("   Carti in biblioteca   ");
        for (Book book : bookCollection) {
            book.displayDetails();
            System.out.println();
        }
        //  LoanService loanService = new LoanService(bookCollection);

//            // Loan a book
//            System.out.println(loanService.loanBook(fictionBook, member0));
//            System.out.println(loanService.loanBook(fictionBook, member1));
//            System.out.println(loanService.loanBook(fictionBook, member2));
//            System.out.println(loanService.loanBook(fictionBook, member3));
//            System.out.println(loanService.loanBook(fictionBook, member4));
//            System.out.println(loanService.loanBook(fictionBook, member5));
//            System.out.println(loanService.loanBook(fictionBook, member6));
//
//            // Display member info and loan history
//            member0.displayInfo();
//            member1.displayInfo();
//            member2.displayInfo();
//            member3.displayInfo();
//            member4.displayInfo();
//            member5.displayInfo();
//            member6.displayInfo();

//          O METODA MAI BUNA AR FI SA FACEM CU UN FOR SI UN ARRAY DE MEMBRII


        // cream membrii
        List<Member> members = new ArrayList<>();
        members.add(new Member("Andrei", "M001"));
        members.add(new Member("Răzvan", "M002"));
        members.add(new Member("Paul", "M003"));
        members.add(new Member("David", "M004"));
        members.add(new Member("Alexandru", "M005"));
        members.add(new Member("Maria", "M006"));
        members.add(new Member("Stefania", "M007"));
        members.add(new Member("Oana", "M008"));
        members.add(new Member("Irina", "M009"));

        // afisam toti membrii
        System.out.println("    Membrii bibliotecii    ");
        for (Member member : members) {
            member.displayInfo();
            System.out.println();
        }

        // cream serviciu de imprumut
        LoanService loanService = new LoanService(bookCollection);

        // exemplu carti imprumutate membrilor
        System.out.println("-- Carti imprumutate --");
        System.out.println(loanService.loanBook(bookCollection.get(0), members.get(0))); // Andrei ia 1984
        System.out.println(loanService.loanBook(bookCollection.get(5), members.get(1))); // Razvan ia A Brief History of Time
        System.out.println(loanService.loanBook(bookCollection.get(10), members.get(2))); // Paul ia Harry Potter
        // afisam istoricul imprumuturilor actualizat
        System.out.println("  Istoricul imprumuturilor actualizat:  ");
        for (Member member : members) {
            member.displayInfo();
            // verificare daca membrul actual a imrumutat sau nu o carte
            //sa nu se afiseze Istoricul imprumutului:  fara nimic dupa :
            if (member.getLoanHistory().isEmpty()) {
                System.out.println("Acest membru nu a împrumutat nici macar o carte.");
            }
            System.out.println();
        }

        // returnarea
        System.out.println("     Returnarea unei carti    ");
        System.out.println("Cartea s-a returnat cu succes: " + loanService.returnBook(bookCollection.get(0)));


        System.out.println("    Search Results for 'Harry Potter' ");
     //   Book[] searchResults = loanService.search("Harry Potter"); //merge pentru stringul exact la fel cum este introdus
    //    Book[] searchResults = loanService.search("harry potter"); //merge daca avem cu litere mici
    //    Book[] searchResults = loanService.search("harry"); //merge si pentru un string partial
    //    Book[] searchResults = loanService.search("hawking"); //si pentru nume
        Book[] searchResults = loanService.search("hawking");// pentru numae cu litera mica partial(substring din el)
        if (searchResults.length == 0) {
            System.out.println("Nu a foat gasit nimic pentru valoarea data.");
        } else {
            for (Book book : searchResults) {
                book.displayDetails();
                System.out.println();
            }
        }



    Book book1 = new FictionBook("1984", "George Orwell", "123456789", true, "Dystopian");
    Book book2 = new NonFictionBook("A Brief History of Time", "Stephen Hawking", "987654321", true, "Science");

    // cream istoricul de imprumuturi pentru un membru (fara a folosi `add`)
    List<Book> loanHistory = Arrays.asList(book1, book2); // folosim `Arrays.asList` pentru a crea lista

    // cream un membru cu istoricul de imprumuturi
    Member andrei = new Member("Andrei", "M010", loanHistory);
       andrei.displayInfo();

        System.out.println();
        System.out.println();//sa le vedem mai bine

       //testam pentru penalizarea ca nu a adus cartea inapoi
        int daysOverdue = 5;  //5 zile de întârziere
        int fine = LoanService.calculateFine(daysOverdue);  // apelam metoda statică
        System.out.println("Pentru cele " + daysOverdue + " zile de întârziere aveti de platit in plus: " + fine + " dolari.");

        daysOverdue = 0;  // Exemplu: 0 zile de întârziere
        fine = LoanService.calculateFine(daysOverdue);  // Apelăm metoda statică
        System.out.println("Pentru cele " + daysOverdue + " zile de întârziere aveti de platit in plus: " + fine + " dolari.");
    }

}


