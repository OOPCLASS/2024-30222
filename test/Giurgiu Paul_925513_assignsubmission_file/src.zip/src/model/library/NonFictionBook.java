package model.library;
//si aici se foloseste tot mostenirea

public class NonFictionBook extends Book {
    private String fieldOfStudy;

    public NonFictionBook(String title, String author, String ISBN, boolean isAvailable, String fieldOfStudy) {
        super(title, author, ISBN, isAvailable);
        this.fieldOfStudy = fieldOfStudy;
    }
//override cu ce mai avem nevoie in plus se numeste la fel avem la fel totul
    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("domeniul de studiu: " + fieldOfStudy);
    }
}
