package model.member;

import java.util.ArrayList;
import java.util.List;
import model.library.Book;

public class Member {
    public String name;
    public String memberID;
    public List<Book> loanHistory;

    public Member(String name, String memberID) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>();
    }

//folosim si constructorul asta sa il verificam
    public Member(String name, String memberID, List<Book> loanHistory) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = loanHistory;
    }

    public void displayInfo() {
        System.out.println("Numele membrului: " + name);
        System.out.println("ID de membru: " + memberID);
        System.out.println("Istoricul imprumutului: ");
        for (Book book : loanHistory) {
            System.out.println("- " + book.title);
        }
    }

    public List<Book> getLoanHistory() {// de tipul List
        return loanHistory;
    }
}
