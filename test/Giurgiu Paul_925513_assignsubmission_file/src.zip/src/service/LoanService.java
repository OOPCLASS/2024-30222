package service;

import java.util.ArrayList;
import java.util.List;
import model.library.Book;
import model.member.Member;

public class LoanService {
    private List<Book> bookCollection;

    public LoanService(List<Book> bookCollection) {
        this.bookCollection = bookCollection;
    }

    public String loanBook(Book book, Member member) {
        if (!book.checkAvailability()) {
            return "Book not available for loaning.";
        }
        book.isAvailable = false;
        member.getLoanHistory().add(book);
        return "Loaning successful.";
    }

    public boolean returnBook(Book book) {
        if (!book.isAvailable) {
            book.isAvailable = true;
            return true;
        }
        return false;
    }

    public static int calculateFine(int daysOverdue) {
        if (daysOverdue > 0) {
            return daysOverdue * 2;  // 2 dolari pe zi de întârziere
        }
        return 0;
    }

    public Book[] search(String value) {
        List<Book> foundBooks = new ArrayList<>();
        String searchValue = value.toLowerCase(); // converteste la minuscule

        // sa parcurgem colectia de carti
        for (Book book : bookCollection) {
            // printf sa vedem daca functioneaza cum vreau
            System.out.println("Cautare in: " + book.getTitle() + " scrisa de: " + book.getAuthor());

            if (book.getTitle().toLowerCase().contains(searchValue) ||
                    book.getAuthor().toLowerCase().contains(searchValue)) {
                foundBooks.add(book); // Add books that match the search
            }
        }

        // sa vedem cand da erori
        if (foundBooks.isEmpty()) {
            System.out.println("No books found for the search term: " + value);
        }

        // returnam rezultatul tot ca un array
        return foundBooks.toArray(new Book[0]);
    }
}
