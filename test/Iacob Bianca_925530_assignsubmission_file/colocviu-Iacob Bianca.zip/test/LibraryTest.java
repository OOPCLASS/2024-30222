//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
package test;

import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;

import java.util.ArrayList;
import java.util.List;

public class LibraryTest
{
    public static void main(String[] args)
    {

        FictionBook fictionBook1 = new FictionBook("Luceafarul", "Mihai Eminescu", "123456789", true, "Poezie");
        NonFictionBook nonFictionBook1 = new NonFictionBook("Romanii", "Necunoscut", "987654321", false, "Istorie");




        fictionBook1.displayDetails();
        System.out.println();
        nonFictionBook1.displayDetails();
        System.out.println();



        Member member1 = new Member("Bianca", "M001");
        Member member2 = new Member("Antonio", "M002", new ArrayList<>(List.of("Romanii")));


        member1.displayInfo();
        System.out.println();
        member2.displayInfo();
        System.out.println();


        LoanService loanService = new LoanService();
        System.out.println("Verif prima carte:");
        System.out.println(loanService.loanBook(fictionBook1, member1));
        System.out.println("Verif a doua carte:");
        System.out.println(loanService.loanBook(nonFictionBook1, member2));



        if (loanService.returnBook(fictionBook1)) {
            System.out.println("Carti returnate cu succes: " + fictionBook1.getTitle());
        }
        System.out.println();


        System.out.println("Amenda pentru 4 zile: " + LoanService.calculateFine(4));
        System.out.println("Amenda pentru 4 zile(VIP): " + LoanService.calculateFine(4, true));

        Book[] searchResultsByTitle = loanService.search("Luceafărul");
        System.out.println(" 'Luceafărul' la titlu:");
        for (Book book : searchResultsByTitle)
        {
            book.displayDetails();
        }


        Book[] searchResultsByAuthor = loanService.search("Iacob");
        System.out.println(" 'Iacob' la autor:");
        for (Book book : searchResultsByAuthor)
        {
            book.displayDetails();
        }

    }
}
