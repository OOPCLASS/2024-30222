package service;

import model.library.Book;
import model.member.Member;
import java.util.List;
import java.util.ArrayList;

public class LoanService
{
    private List<Book> bookList=new ArrayList<>();

    public String loanBook(Book book, Member member)
    {
        if (book.checkAvailability())
        {
            bookList.add(book); // Add book to borrowed list
            member.getLoanHistory().add(book.getTitle());
            book.setAvailable(false);
            return "Loaning successful";
        } else {
            return "Book not available for loaning";
        }

    }

    public boolean returnBook(Book book)
    {
        if (!book.checkAvailability())
        {
            book.setAvailable(true);
            return true;
        }
        return false;
    }

    public static int calculateFine(int daysOverdue)
    {
        return daysOverdue * 2;
    }

    public static int calculateFine(int daysOverdue, boolean isMemberVIP)
    {
        int fine = daysOverdue * 2;
        return isMemberVIP ? fine / 2 : fine;
    }

    public Book[] search(String value)
    {
        List<Book> result = new ArrayList<>();
        for (Book book : bookList)
        {
            if (book.getTitle().toLowerCase().contains(value.toLowerCase()) || book.getAuthor().toLowerCase().contains(value.toLowerCase()))
            {
                result.add(book);
            }
        }
        return result.toArray(new Book[0]);
    }


}

