package model.member;
import java.util.ArrayList;
import java.util.List;
import model.library.Book;

public class Member {
    private String name;
    private int memberID;
    ArrayList<String> loanHistory;

    public Member(String name, int memberID) {
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>();
    }

    public Member(String name, int memberID, List<String> loanHistory){
        this.name = name;
        this.memberID = memberID;
        this.loanHistory = new ArrayList<>(loanHistory);
    }

    public void display(){
        System.out.println("Member Name: " + name);
        System.out.println("Member ID: " + memberID);
        System.out.println("Loan History: " + loanHistory);
    }

    public void addLoan(String loan){
        loanHistory.add(loan);  //add book
    }

    public void removeLoan(String loan){
        loanHistory.remove(loan); //remove book
    }

    public List<String> getLoanHistory(){
        return new ArrayList<>(loanHistory);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
