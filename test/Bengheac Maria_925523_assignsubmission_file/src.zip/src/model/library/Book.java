package model.library;

public class Book {
    private String title;
    private String author;
    private String ISBN;
    private boolean isAvailable;

    public void displayDetails() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("ISBN: " + ISBN);
        System.out.println("Available: " + (isAvailable ? "true" : "false"));

        System.out.println();
    }

    public Book() {
        author = "necunoscut";
        title = "necunoscut";
        ISBN = "0";
        isAvailable = true;
    }

    public Book(String title, String author, String ISBN, boolean isAvailable) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isAvailable = isAvailable;
    }

    public boolean isAvailable() {
        if(isAvailable)
            return true;
        return false;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getISBN(){
        return ISBN;
    }

    public void Availability(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }
}
