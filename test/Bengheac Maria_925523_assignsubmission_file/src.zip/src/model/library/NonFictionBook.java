package model.library;

public class NonFictionBook extends Book {
    public String FieldOfStudy;

    public NonFictionBook(String title, String author, String ISBN, String FieldOfStudy, boolean isAvailable) {
        super(title,author,ISBN,isAvailable);
        this.FieldOfStudy = FieldOfStudy;
    }

    public void displayDetails(){

        System.out.println("FieldOfStudy: " + FieldOfStudy);
        super.displayDetails();
    }
}
