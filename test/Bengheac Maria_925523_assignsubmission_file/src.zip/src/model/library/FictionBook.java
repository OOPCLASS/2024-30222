package model.library;

public class FictionBook extends Book {
    public String Genre;

    public FictionBook(String title, String author, String ISBN, String genre, boolean isAvailable) {
        super(title,author,ISBN,isAvailable);
        this.Genre = genre;
    }
    public void displayDetails(){
        //super.displayDetails();
        System.out.println("Genre: " + Genre);
        super.displayDetails();
        //System.out.println();
    }
}
