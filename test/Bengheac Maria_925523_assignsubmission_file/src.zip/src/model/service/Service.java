package model.service;

import model.library.Book;
import model.member.Member;

import java.util.ArrayList;
import java.util.List;

public class Service extends Book {
    public static String loanBook(Book book, Member member) {
        if(!book.isAvailable()) {
            return "The book: "+ book.getTitle() +" is not available";
        }

        book.Availability(false);

        member.addLoan(book.getTitle());
        return  "The book '" + book.getTitle() + "' has been loaned to member " + member.getName() + ".";
    }

    public boolean returnBook(Book book) {
        if(book.isAvailable()) {
            System.out.println("The book '" + book.getTitle() + "' is already loaned");
            return false;
        }

        book.Availability(true);
        System.out.println("The book '" + book.getTitle() + "' has been returned.");
        return true;
    }

    public static int calculateFine(int daysOverdue) {
        int fineDay = 2;

        return fineDay * daysOverdue;
    }

    private List<Book> books = new ArrayList<>();

    public void addBook(Book book) {
        books.add(book);
    }

    public Book[] search(String value){
        List<Book> loanedBooks = new ArrayList<>();
        for(Book book : books) {
            if(book.getTitle().toLowerCase().contains(value.toLowerCase())) {
                loanedBooks.add(book);
            }
        }
        return loanedBooks.toArray(new Book[loanedBooks.size()]);
    }
}
