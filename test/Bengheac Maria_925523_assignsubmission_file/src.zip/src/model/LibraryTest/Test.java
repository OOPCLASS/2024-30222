package model.LibraryTest;

import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import model.service.Service;

import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
        Book b1 = new Book("Ion", "Liviu Rebreanu", "0099-098", true);
        b1.displayDetails();

        FictionBook b2 = new FictionBook("Casa din padure", "Florin Pop","780-023", "Fictional",false);
        b2.displayDetails();

        NonFictionBook b3 = new NonFictionBook("Cooking 101", "Chef Anne", "987-654", "Cooking", true);
        b3.displayDetails();

        Member m1 = new Member("Bob", 12, Arrays.asList("To Kill a Mockingbird", "Sapiens"));
        Member m2 = new Member("Bob Brown", 023, Arrays.asList("My dream", "History"));

        m1.addLoan("Cei trei purcelusi");
        m1.removeLoan("To Kill a Mockingbird");

        Member m3 = new Member("Alice", 13);

        m1.display();
        System.out.println();

        m2.display();
        System.out.println();

        m3.display();
        System.out.println();

        Service service = new Service();
        boolean result = service.returnBook(b1);
        boolean result2 = service.returnBook(b2);
        boolean result3 = service.returnBook(b3);

        System.out.println();
        System.out.println(result);

        int f1 = Service.calculateFine(5);
        System.out.println("Fine to pay: " +f1+"$" );

        int f2 = Service.calculateFine(0);
        System.out.println("Fine to pay: " +f2+"$" );

        int f3 = Service.calculateFine(12);
        System.out.println("Fine to pay: " +f3+"$" );

        System.out.println();

        Service service2 = new Service();
        service.addBook(b1);
        service.addBook(b2);

        Book[] results = service.search("book");

        System.out.println("results: ");
        b1.displayDetails();
        b2.displayDetails();
        b3.displayDetails();

        for(Book b : results){
            b.displayDetails();
            System.out.println();
        }


    }
}
