package service;
import library.*;
import member.Member;
import java.util.ArrayList;

public class LoanService {

    public ArrayList<Book> books;

    public LoanService() {books=new ArrayList<>(100);}

    public String loanBook(Book book,Member member) {
        for(Book b: books) {
            if (b == book && b.checkAvailability()) {
                book.available = false;
                member.books.add(book);
                return "loaning successful";
            }
        }
        return "book not available for loaning";
    }

    public boolean returnBook(Book book) {
        for(Book b: books) {
        if (b==book && !b.checkAvailability()) {
            book.available = true;
            return true;
        }
    }
        return false;
    }

    static int calculateFine(int daysOverdue) {return 2*daysOverdue;}

    static int calculateFine(int daysOverdue,boolean isMemberVIP) {
      int a=calculateFine(daysOverdue);
      if(isMemberVIP)
          return a/2;
      else return a;
    }

    public ArrayList<Book> search(String title) {
        ArrayList<Book> booksReturned = new ArrayList<>(100);
        for(Book b: books) {
            if(b.getTitle().toLowerCase().contains(title.toLowerCase()))
                booksReturned.add(b);
        }
        return booksReturned;
    }

    public void addBook(Book book) {books.add(book);}

    public void printBooks()
    {
        for(Book b: books)
            System.out.println(b);
    }
}
