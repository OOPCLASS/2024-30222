package library;

public class NonFictionBook extends Book {
   String fieldOfStudy;

   public NonFictionBook(String title, String author, boolean available, String fieldOfStudy) {
       super(title, author, available);
       this.fieldOfStudy = fieldOfStudy;
   }

   public void displayDetails() {
        System.out.println("Title: " + getTitle());
        System.out.println("Author: " + getAuthor());
        System.out.println("ISBN: " + getISBN());
        System.out.println("Available: " + available);
        System.out.println("Field of study: " + fieldOfStudy);
    }
}
