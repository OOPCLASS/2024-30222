package library;

public class Book {
    private  String title;
    private String author;
    private int ISBN;
    public boolean available;

    public Book(String title, String author,boolean available) {
        this.title = title;
        this.author = author;
        this.available = available;
    }

    public void displayDetails() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("ISBN: " + ISBN);
        System.out.println("Available: " + available);
    }

    public boolean checkAvailability() {return available;}

    public String getTitle() {return this.title;}

    public String getAuthor() {return this.author;}

    public int getISBN() {return this.ISBN;}
}
