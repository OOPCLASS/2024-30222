package library;

public class FictionBook extends Book {
    private String genre;

    public FictionBook(String title, String author, boolean available, String genre) {
        super(title,author,available);
        this.genre = genre;

    }

    public void displayDetails() {
        System.out.println("Title: " + getTitle());
        System.out.println("Author: " + getAuthor());
        System.out.println("ISBN: " + getISBN());
        System.out.println("Available: " + available);
        System.out.println("Genre: " + this.genre);
    }
}
