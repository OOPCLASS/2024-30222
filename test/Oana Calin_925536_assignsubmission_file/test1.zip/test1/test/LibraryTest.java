package test;
import library.*;
import member.Member;
import service.LoanService;
import java.util.ArrayList;
import java.util.List;

public class LibraryTest {

    LoanService ls=new LoanService();

    Book b1=new FictionBook("Carte1","Autor1",true,"SF1");
    Book b2=new FictionBook("Carte2","Autor2",true,"SF2");
    Book b3=new NonFictionBook("Carte3","Autor3",true,"roman3");
    Book b4=new NonFictionBook("Carte4","Autor4",true,"roman4");


    Member m1=new Member("Member1",1);
    Member m2=new Member("Member2",2);
    Member m3=new Member("Member3",3);


}
