import test.LibraryTest;

public class Main {
    public static void main(String[] args) {
       LibraryTest l=new LibraryTest();
    }
}