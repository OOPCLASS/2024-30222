package member;
import library.*;
import java.util.ArrayList;

public class Member {
    private String name;
    private int memberID;
    public ArrayList<Book> books;

    public Member(String name, int memberID) {
        this.name = name;
        this.memberID = memberID;
    }

    public Member(String name,int memberID,ArrayList<Book> books) {
        this.name = name;
        this.memberID = memberID;
        this.books = books;
    }

    public void displayInfo() {
        System.out.println("Name: " + this.name);
        System.out.println("Member ID: " + this.memberID);
        System.out.println("LoanHistory: ");
        for(Book book : books)
            System.out.println(book.getTitle() + " ");
        System.out.println();
    }
}
