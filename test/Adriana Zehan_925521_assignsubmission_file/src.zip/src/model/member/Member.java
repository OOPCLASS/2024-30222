package model.member;

import java.util.ArrayList;
import java.util.List;

public class Member {
    private String name;
    private String memberID;
    private boolean isVip; // Consistent naming with 'isVip'
    private List<String> loanHistory; // Vector pentru istoricul imprumuturilor unui membru

    // Constructor de initializare a unui membru nou cu nume si id
    public Member(String name, String memberID, boolean isVip) {
        this.name = name;
        this.memberID = memberID;
        this.isVip = isVip;
        this.loanHistory = new ArrayList<>();
    }

    // Constructor pentru cazul in care membrul curent are un istoric de imprumuturi
    public Member(String name, String memberID, boolean isVip, List<String> loanHistory) {
        this.name = name;
        this.memberID = memberID;
        this.isVip = isVip;
        this.loanHistory = loanHistory != null ? loanHistory : new ArrayList<>();
    }

    // Display information about the member
    public void displayInfo() {
        System.out.println("Name: " + name + ", Member ID: " + memberID);
        System.out.println("Loan History: " + loanHistory);
    }

    // Setter for VIP status
    public void setVIPStatus(boolean isVip) {
        this.isVip = isVip;
    }

    // Getter for VIP status
    public boolean isMemberVIP() {
        return isVip; //verific daca un membru este sau nu vip
    }

    // Add a new loan to the member's loan history
    public void addLoanToHistory(String bookTitle) {
        loanHistory.add(bookTitle);
    }
}

