package model.library;

public class NonFictionBook extends Book {
    private String fieldOfStudy;

    public NonFictionBook(String title, String author, String ISBN, String fieldOfStudy) {
        super(title, author, ISBN); //atributele comune cu cele ale clasei parinte Book
        this.fieldOfStudy = fieldOfStudy;
    }

    @Override
    public void displayDetails() {
        super.displayDetails(); //afisare atribute comune cu cele ale clasei parinte Book
        System.out.println("Field of Study: " + fieldOfStudy);
    }
}
