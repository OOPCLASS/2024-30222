package model.library;

public class FictionBook extends Book{
    private String genre;

    public FictionBook(String title, String author, String ISBN, String genre) {
        super(title, author, ISBN); //atributele comune cu cele ale clasei parinte Book
        this.genre = genre;
    }

    @Override
    public void displayDetails() {
        super.displayDetails(); //afisare atribute comune cu cele ale clasei parinte Book
        System.out.println("Genre: " + genre);
    }
}
