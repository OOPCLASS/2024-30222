package service;
import model.library.Book;
import model.member.Member;
import java.util.ArrayList;
import java.util.List;

public class LoanService
{
    private List<Book> books = new ArrayList<>(); //crearea unui array de tipul Book

    public String loanBook(Book book, Member member) { //verific daca o carte poate fi imprumutata sau
        //a fost deja imprumutata si nu mai e disponibila
        if (book.checkAvailability()) {
            book.setAvailable(false); //odata ce cartea a fost imprumutata de un membru
            // ii setez disponibilitatea ca fiind falsa
            member.addLoanToHistory(book.getTitle()); //si o adaug la istoricul de imprumut al membrului curent
            return "Loaning successful";
        }
        return "Book not available for loaning";
    }

    public boolean returnBook(Book book) {
        if (!book.checkAvailability()) {
            book.setAvailable(true);
            return true;
        }
        return false;
    } //odata ce o carte a fost inapoiata devine disponibila in stocul bibliotecii

    public static int calculateFine(int daysOverdue) {
        return daysOverdue * 2; //in cazul in care nu se respecta termenul de imprumut se aplica o penalizare
    } //calculeaza valoarea teoretica a penalizarii

    public static int calculateFine(int daysOverdue, boolean isMemberVIP) {
        int fine = calculateFine(daysOverdue);
        return isMemberVIP ? fine / 2 : fine;
    } //calculeaza valoarea personalizata a penalizarii in functie de membru, daca este vip sau nu

    public Book[] search(String value) { //daca string ul value se regaseste in titlul cartii sau al
        //autorului, returneaza toate cartile care indeplinesc conditia, nefiind cse sensitive
        List<Book> results = new ArrayList<>();
        for (Book book : books)
        {
            if (book.getTitle().toLowerCase().contains(value.toLowerCase()) ||
                    book.getAuthor().toLowerCase().contains(value.toLowerCase())) {
                results.add(book);
            }
        }
        return results.toArray(new Book[0]);
    }

    public Book[] search1(String value) //cautare dupa autor sau titlul cartii
    {
        List<Book> results = new ArrayList<>();
        for (Book book : books)
        {
            String s1=book.getTitle(); //book.getAuthor pentru a verifica cartile de un anumit autor
            boolean result1 = s1.equals(value);
            if (result1)
            {
                results.add(book);
            }
        }
        return results.toArray(new Book[0]);
    }

    public void addBook(Book book) { //adauga o carte in array ul celor imprumutate
        books.add(book);
    }
}
