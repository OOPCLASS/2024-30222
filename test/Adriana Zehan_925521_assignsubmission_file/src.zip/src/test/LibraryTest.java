package test;
import model.library.*;
import model.member.Member;
import service.LoanService;

import java.util.ArrayList;
import java.util.List;

public class LibraryTest {
    public static void main(String[] args)
    {
        // Create books
        FictionBook book1 = new FictionBook("Nightbane", "Alex Aster", "1234", "Fantasy");
        NonFictionBook book2 = new NonFictionBook("Natural wonders of the world", "Chris Packham", "5678", "Science");

        // Create members
        Member member1 = new Member("Joe", "M001", true); //este vip
        List<String> history = new ArrayList<>();
        //history.add("Old Book");
        Member member2 = new Member("John", "M002", false, history); //nu e vip

        // Loan service
        LoanService loanService = new LoanService();
        loanService.addBook(book1);
        loanService.addBook(book2);

        // Loaning books
        System.out.println(loanService.loanBook(book1, member1));
        System.out.println(loanService.loanBook(book1, member2)); // cartea e deja imprumutata, deci nu se
        //mai poate imprumuta de al doilea membru aceeasi carte

        // Returning books
        System.out.println(loanService.returnBook(book1)); //dupa returnarea cartii disponibilitatea sa redevine true

        // Fine calculation
        System.out.println("Fine: $" + LoanService.calculateFine(5));
        System.out.println("The fine for vip member is: ");
        System.out.println("Fine: $"+ LoanService.calculateFine(5,member1.isMemberVIP()));
        System.out.println("The fine for not a vip member is: ");
        System.out.println("Fine: $"+ LoanService.calculateFine(5,member2.isMemberVIP()));

        System.out.println("\n");

        // Displaying details
        book1.displayDetails();
        System.out.println("\n");
        book2.displayDetails();
        System.out.println("\n");

        member1.displayInfo();
        System.out.println("\n");
        member2.displayInfo();
        System.out.println("\n");

        // Searching books
        Book[] searchResults = loanService.search("Natural");

        System.out.println("Search Results:");
        for (Book book : searchResults) {
            book.displayDetails();
        }
    }
}
