package test;

import model.library.Book;
import model.library.FictionBook;
import model.library.NonFictionBook;
import model.member.Member;
import service.LoanService;

public class LibraryTest {
    public static void main(String[] args) {
        LoanService loanService = new LoanService();
        Book[] books = new Book[10];
        books[0] = new FictionBook("Harry Potter", "JK Rowling","fiction", "1234jh6stt3f", true);
        books[1] = new FictionBook("Harry Potter2", "JK Rowling","fiction", "ttt4jhh123f", true);
        books[2] = new FictionBook("Harry Potter3", "JK Rowling","fiction", "12fgghh123f", true);
        books[3] = new NonFictionBook("6 easy pieces", "Richard Feynman", "123241sfash", "physics", true);
        books[4] = new NonFictionBook("World History", "JM Roberst", "123111sf22h", "history", true);

        for(int i = 0; i < 5; i++){
            LoanService.addBook(books[i]);
        }

        Member[] members = new Member[10];
        members[0] = new Member("Andrei", "1");
        members[0].addLoan(books[1]);
        members[0].addLoan(books[2]);

        members[1] = new Member("Paul", "2");
        members[2] = new Member("Dragos", "3");
        members[3] = new Member("Iulian", "4");
        members[3].addLoan(books[3]);
        members[3].addLoan(books[4]);

        members[4] = new Member("Razvan", "5");


        for(int i = 0; i < 5; i++){
            LoanService.addMember(members[i]);
        }

        for(int i = 0; i < 5; i++){
            LoanService.books[i].displayDetails();
        }

        for(int i = 0; i < 5; i++){
            LoanService.members[i].displayInfo();
        }

        System.out.println(loanService.loanBook(books[1], members[1]));
        System.out.println(loanService.loanBook(books[4], members[4]));
        loanService.returnBook(books[4]);
        System.out.println(loanService.loanBook(books[4], members[4]));

        System.out.println(LoanService.calculateFine(members[0].loanHistory[0].calcdaysOverdue(), false));
    }
}
