package service;

import model.library.Book;
import model.member.Member;

public class LoanService {

    public static Book[] books = new Book[30];
    public static int bookCounter = 0;
    public static Member[] members = new Member[10];
    public static int memberCounter = 0;

    public static void addBook(Book book) {
        books[bookCounter] = book;
        bookCounter++;
    }

    public static void addMember(Member member) {
        members[memberCounter] = member;
        memberCounter++;
    }

    public String loanBook(Book book, Member member) {
        if(book.checkAvailability()){
            book.setAvailable(false);
            member.addLoan(book);
            return "Loaning successful";
        }
        return "Book not available for loaning";
    }

    public boolean returnBook(Book book) {
        book.setAvailable(true);
        return true;
    }

    public static long calculateFine(long daysOverdue){
        return 2*daysOverdue;
    }

    public static long calculateFine(long daysOverdue, boolean isMemberVip){
        if(isMemberVip){
            return calculateFine(daysOverdue) - calculateFine(daysOverdue)/2;
        }else
            return calculateFine(daysOverdue);
    }

    public Book[] search(String value) {
        Book[] booksSearched = new Book[30];
        int counter = 0;
        for(int i = 0; i < books.length; i++){
            String bufValue = value.toLowerCase();
            String bufTitle = books[i].getTitle().toLowerCase();
            String bufAuthor = books[i].getAuthor().toLowerCase();
            if(bufTitle.contains(bufValue) || bufAuthor.contains(bufValue)){
                booksSearched[counter] = books[i];
                counter++;
            }
        }
        return booksSearched;
    }


}
