package model.library;

public class NonFictionBook extends Book {
    private String fieldOfStudy;

    public String getFieldOfStudy() {
        return fieldOfStudy;
    }

    public void setFieldOfStudy(String fieldOfStudy) {
        this.fieldOfStudy = fieldOfStudy;
    }

    public NonFictionBook() {
        super();
    }

    public NonFictionBook(String title, String author, String isbn, String fieldOfStudy, boolean isAvailable) {
        super(title, author, isbn, isAvailable);
        this.fieldOfStudy = fieldOfStudy;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Field of study: " + fieldOfStudy);
    }
}
