package model.member;

import model.utils.RandomDates;
import model.library.Book;

import java.time.LocalDate;

public class Member {
    private String name;
    private String memberID;
    public Loans[] loanHistory = new Loans[10];
    private int loanCounter;

    public int getLoanCounter() {
        return loanCounter;
    }

    public void setLoanCounter(int loanCounter) {
        this.loanCounter = loanCounter;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemberID() {
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

//    public Loans[] getLoanHistory() {
//        return loanHistory;
//    }
//
//    public void setLoanHistory(Loans[] loanHistory) {
//        this.loanHistory = loanHistory;
//    }

    public Member(String name, String memberID) {
        this.name = name;
        this.memberID = memberID;
    }

    public Member(String name, String memberID, Loans[] loans) {
        this(name, memberID);
        this.loanHistory = loans;
        this.loanCounter = 0;
    }

    public void displayInfo(){
        System.out.println("Name: " + name);
        System.out.println("Member ID: " + memberID);
        System.out.println("Loans: ");
        if(loanCounter == 0)
            System.out.println("No loans");
        for(Loans loan : loanHistory){
            if(loan != null){
                loan.displayLoanInfo();
            }
        }
    }

    public void addLoan(Book book){
        if(this.loanCounter < 10) {
            book.setAvailable(false);
            LocalDate startDate = LocalDate.of(2024, 5, 11);
            LocalDate endDate = RandomDates.createRandomDate(2021, 2025);
            loanHistory[this.loanCounter] = new Loans(startDate, endDate, book.getTitle());
            this.loanCounter++;
        }else
        {
            System.out.println("You can not loan any more books!");
        }
    }


}
