package model.member;

import java.time.LocalDate;
import java.util.Date;

import static java.time.temporal.ChronoUnit.DAYS;

public class Loans {
    private LocalDate startDate;
    private LocalDate endDate;
    private String loanedBook;

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getLoanedBook() {
        return loanedBook;
    }

    public void setLoanedBook(String loanedBook) {
        this.loanedBook = loanedBook;
    }

    public Loans(LocalDate startDate, LocalDate endDate, String loanedBook) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.loanedBook = loanedBook;
    }

    public void displayLoanInfo() {
        System.out.println("StartDate: " + startDate);
        System.out.println("EndDate: " + endDate);
        System.out.println("LoanedBook: " + loanedBook);
    }

    public long calcdaysOverdue(){

        return DAYS.between(this.startDate, this.endDate);

    }
}
